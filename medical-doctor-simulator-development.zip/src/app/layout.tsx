import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "@fontsource/rubik/cyrillic-500.css";
import "@fontsource/rubik/cyrillic-700.css";
import "@fontsource/rubik/cyrillic-800.css";
import "@fontsource/rubik/latin-500.css";
import "@fontsource/rubik/latin-700.css";
import "@fontsource/rubik/latin-800.css";
import "./globals.css";

export const metadata: Metadata = {
  title: "Белый Халат: карьера врача",
  description: "Мини-игра: поднимись с практиканта до главного врача больницы. Лечи, интригуй, принимай решения.",
};
export const viewport: Viewport = { width: "device-width", initialScale: 1, maximumScale: 1, userScalable: false, themeColor: "#0d2347" };

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ru">
      <body>{children}</body>
    </html>
  );
}
