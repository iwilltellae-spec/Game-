import GameApp from "@/game/ui/GameApp";

export default function HomePage() {
  return <GameApp />;
}
