import type { GameState, Patient, Fx, TraitId, Dose, TestId, Inpatient, Choice } from "./types";
import { DISEASES, DIS, DRUG, DRUGS, patientTags, type Disease } from "./meds";
import { PORTRAITS, NAMES, RANKS, QUESTS, SHOP } from "./data";
import { EVENTS } from "./events";

export const SAVE_KEY = "belyi_khalat_save_v1";
export const rnd = (a: number, b: number) => a + Math.floor(Math.random() * (b - a + 1));
export const pick = <T,>(a: T[]): T => a[Math.floor(Math.random() * a.length)];
export const clamp = (n: number, a: number, b: number) => Math.max(a, Math.min(b, n));
export const clone = <T,>(x: T): T => structuredClone(x);
const fmt = (n: number) => Math.round(n).toLocaleString("ru-RU");

export function freshState(legacy = 0, name = "", sig: string | null = null): GameState {
  const s: GameState = {
    v: 1, name, sig, started: false, intro: 0, tips: {}, day: 1, time: 12, maxTime: 12,
    money: 600 + legacy * 300, xp: 0, rank: 0, sp: 1, spGiven: 0,
    skills: { diag: 1, pharm: 0, empathy: 0, diplo: 0, hands: 0 },
    stress: 10, rating: 40, warn: 0, rel: { boss: 10, lev: 10, nurse: 0, rival: 0, team: 0 },
    dossier: 0, path: { flat: 0, whistle: 0, rebel: 0 }, flags: { scheme: 1 },
    stock: { para: 6, ibu: 4, asp: 2, amox: 4, azi: 2, cef: 2, osel: 3, lor: 4, omep: 4, drot: 3, smec: 4, gluc: 2, salin: 4, keto: 2, adre: 1, naz: 3, ambr: 3, chlor: 4, levo: 3, diclo: 3, val: 3, splint: 2, eye: 3, panth: 3 },
    owned: [], staff: [], queue: [], ward: [], cash: 0, cashT: Date.now(), nid: 1,
    daily: { cured: 0, earned: 0, perfInj: 0, red: 0, tests: 0, calm: 0, quests: [] },
    cd: {}, log: [], pending: [], summary: null, over: null, legacy,
    totals: { cured: 0, deaths: 0, shifts: 0 }, loc: "lobby", consult: null, toast: null,
  };
  newQuests(s);
  return s;
}

export const maxTimeOf = (s: GameState) => 12 + (s.owned.includes("coffee") ? 1 : 0) - (s.stress >= 80 ? 2 : 0);
export const queueCap = (s: GameState) => 4 + (s.owned.includes("q6") ? 2 : 0) + (s.staff.includes("admin") ? 1 : 0);
export const bedCap = (s: GameState) => 2 + ["b3", "b4", "b5", "b6"].filter((x) => s.owned.includes(x)).length;
export const flag = (s: GameState, k: string) => s.flags[k] || 0;
export const rankMult = (s: GameState) => 1 + s.rank * 0.25;

export function note(s: GameState, msg: string) {
  s.log.unshift(`День ${s.day}: ${msg}`);
  if (s.log.length > 40) s.log.length = 40;
  s.toast = msg;
}

/* ---------- effects ---------- */
const REL_N: Record<string, string> = { boss: "Громов", lev: "Левицкий", nurse: "Зинаида", rival: "Диана", team: "Коллектив" };
export function addXp(s: GameState, n: number) {
  s.xp += n;
  const g = Math.floor(s.xp / 110) - s.spGiven;
  if (g > 0) { s.sp += g; s.spGiven += g; }
}
export function applyFx(s: GameState, fx: Fx): string[] {
  const out: string[] = [];
  const arrow = (k: string, v: number) => out.push(`${REL_N[k]} ${v > 0 ? "▲" : "▼"}`);
  if (fx.money) { s.money = Math.max(0, s.money + fx.money); out.push(`Деньги ${fx.money > 0 ? "+" : ""}${fmt(fx.money)}`); }
  if (fx.xp) { addXp(s, fx.xp); out.push(`Опыт +${fx.xp}`); }
  if (fx.stress) { s.stress = clamp(s.stress + fx.stress, 0, 100); out.push(`Нервы ${fx.stress > 0 ? "+" : ""}${fx.stress}`); }
  for (const k of ["boss", "lev", "nurse", "rival", "team"] as const) {
    const v = fx[k];
    if (v) { s.rel[k] = clamp(s.rel[k] + v, -100, 100); arrow(k, v); }
  }
  if (fx.dossier) { s.dossier = Math.max(0, s.dossier + fx.dossier); out.push(`Досье ${fx.dossier > 0 ? "+" : ""}${fx.dossier}`); }
  if (fx.warn) { s.warn = Math.max(0, s.warn + fx.warn); if (fx.warn > 0) s.flags.lastWarn = s.day; out.push(fx.warn > 0 ? "Выговор" : "Выговор снят"); }
  if (fx.rating) { s.rating = clamp(s.rating + fx.rating, 0, 100); out.push(`Рейтинг ${fx.rating > 0 ? "+" : ""}${fx.rating}`); }
  if (fx.flat) s.path.flat += fx.flat;
  if (fx.whistle) s.path.whistle += fx.whistle;
  if (fx.rebel) s.path.rebel += fx.rebel;
  if (fx.sp) { s.sp += fx.sp; out.push(`Очко навыков +${fx.sp}`); }
  if (fx.time) { s.time = clamp(s.time + fx.time, 0, 20); out.push(`Время ${fx.time > 0 ? "+" : ""}${fx.time} ч`); }
  if (fx.set) for (const [k, v] of Object.entries(fx.set)) s.flags[k] = v;
  if (fx.stock) for (const [k, v] of Object.entries(fx.stock)) { s.stock[k] = Math.max(0, (s.stock[k] || 0) + v); out.push(`${DRUG[k]?.name ?? k} ${v > 0 ? "+" : ""}${v}`); }
  if (fx.redPatients) for (let i = 0; i < fx.redPatients; i++) s.queue.push(genPatient(s, { red: true }));
  if (fx.rush) for (let i = 0; i < fx.rush; i++) s.queue.push(genPatient(s, {}));
  if (fx.bossPatient) { const b = genPatient(s, { disease: "infarct", boss: true }); b.patience = 3; b.maxPatience = 3; s.queue.unshift(b); s.loc = "lobby"; }
  if (fx.demote) demote(s);
  if (fx.promote && s.rank < RANKS.length - 1) { s.rank++; s.sp += 2; if (s.xp < RANKS[s.rank].xp) s.xp = RANKS[s.rank].xp; out.push(`Новая должность: ${RANKS[s.rank].name}`); }
  if (fx.fire && !s.over) s.over = { kind: "fired", text: fx.fire };
  syncQuests(s);
  checkOver(s);
  return out;
}
function demote(s: GameState) {
  if (s.rank === 0) { s.stress = Math.min(100, s.stress + 10); s.rating = Math.max(1, s.rating - 5); note(s, "Тебя оставили на испытательном сроке"); return; }
  s.rank--; s.xp = Math.min(s.xp, RANKS[s.rank + 1].xp - 1); s.flags.demotions = flag(s, "demotions") + 1;
  note(s, `Понижение: ${RANKS[s.rank].name}`);
}
export function checkOver(s: GameState) {
  if (s.over) return;
  if (s.warn >= 3) {
    if (s.rank === 0 && !flag(s, "probation")) { s.flags.probation = 1; s.warn = 1; s.rating = Math.max(1, s.rating - 5); note(s, "Громов дал последний шанс: испытательный срок продлён"); }
    else if (flag(s, "demotions") >= 1 || s.rank === 0) s.over = { kind: "fired", text: "Три выговора и уже было понижение. Приказ об увольнении подписан сегодня." };
    else { demote(s); s.warn = 1; }
  }
  if (s.rating <= 0) s.over = { kind: "fired", text: "Рейтинг больницы упал до нуля. Комиссия закрыла отделение, а виноватой назначили тебя." };
  if (flag(s, "dd") >= 4) s.over = { kind: "fired", text: "Слишком много трагедий. Дело передали в следственный комитет, лицензия аннулирована." };
}

/* ---------- patients ---------- */
function eligible(d: Disease, pk: string): boolean {
  const pi = PORTRAITS[pk];
  if (d.only && !d.only.includes(pk)) return false;
  if (d.fem && pi.sex !== "f") return false;
  if (d.noPreg && pi.preg) return false;
  if (d.adultOnly) return pi.age[0] >= 18;
  if (d.kids) return true;
  return pi.age[0] >= 6;
}
export function genPatient(s: GameState, o: { red?: boolean; disease?: string; portrait?: string; boss?: boolean; patient?: number } = {}): Patient {
  let d: Disease | undefined = o.disease ? DIS[o.disease] : undefined;
  let pk = o.portrait;
  if (!d) {
    let pool = DISEASES.filter((x) => x.rank <= s.rank + (Math.random() < 0.12 ? 1 : 0) && x.pay >= 0);
    if (o.red) { const r = pool.filter((x) => x.sev === 3); pool = r.length ? r : pool.filter((x) => x.sev >= 2); }
    const dup = new Set(s.queue.map((q) => q.disease));
    const bag: Disease[] = [];
    for (const x of pool) { const w = x.sev === 3 && !o.red ? 1 : 3; for (let i = 0; i < w; i++) if (!dup.has(x.id) || Math.random() < 0.2) bag.push(x); }
    d = pick(bag.length ? bag : pool);
  }
  const keys = Object.keys(PORTRAITS);
  if (!pk) { const el = keys.filter((k) => eligible(d!, k)); pk = pick(el.length ? el : keys); }
  const pi = PORTRAITS[pk];
  const age = rnd(pi.age[0], pi.age[1]);
  const sex = pi.sex;
  const surname = pick(sex === "m" ? NAMES.mF : NAMES.fF);
  const name = pi.baby ? `Малыш ${surname}` : `${surname} ${pick(sex === "m" ? NAMES.mN : NAMES.fN)}`;
  let trait: TraitId = pick(pi.traits);
  if (d.id === "healthy") trait = "cunning";
  if (o.red) trait = pick(["calm", "anxious"]);
  let allergy: string | null = Math.random() < 0.18 ? pick(["a_pen", "a_asp"]) : null;
  let chronic: string | null = d.chronic ?? null;
  if (pi.preg) chronic = "c_preg";
  if (!chronic && age >= 40 && Math.random() < 0.18) chronic = pick(["c_heart", "c_kidney", "c_diab", "c_ulcer", "c_asthma"]);
  // trap: make the most obvious drug dangerous sometimes
  if (Math.random() < Math.min(0.4, 0.12 + 0.04 * s.rank) && Object.keys(d.tx).length) {
    const top = Object.entries(d.tx).sort((a, b) => b[1] - a[1])[0][0];
    const c = DRUG[top].contra;
    const al = c.filter((t) => t.startsWith("a_"));
    const ch = c.filter((t) => t.startsWith("c_") && t !== "c_preg");
    if (al.length) allergy = pick(al); else if (ch.length && age >= 18 && !chronic) chronic = pick(ch);
  }
  const mp = d.sev === 3 ? 3 : d.sev === 2 ? 6 : 9;
  const patience = Math.max(2, mp + (trait === "anxious" ? -1 : 0) + (s.staff.includes("admin") ? 2 : 0) + (s.owned.includes("tv") ? 2 : 0) + (s.owned.includes("sofa") ? 1 : 0) - (d.sev === 3 ? 1 : 0) + (d.sev === 3 && s.owned.includes("tv") ? -2 : 0));
  const id = s.nid++;
  return { id, portrait: o.boss ? "boss" : pk, name: o.boss ? "Аркадий Громов" : name, age: o.boss ? 67 : age, sex: o.boss ? "m" : sex, disease: d.id, allergy: o.boss ? null : allergy, chronic: o.boss ? "c_heart" : chronic, trait: o.boss ? "calm" : trait, patience, maxPatience: patience, sev: d.sev, asked: [], tested: [], conflictDone: !!o.boss, isBoss: o.boss };
}

export function arrive(s: GameState, force = false) {
  if (s.queue.length >= queueCap(s)) return;
  const red = Math.random() < (s.rank >= 1 ? 0.14 : 0.06) && s.rank >= 0 && s.day > 2;
  if (force || Math.random() < 0.6) s.queue.push(genPatient(s, { red }));
}

export function patientDie(s: GameState, p: Patient, why: string): string {
  s.totals.deaths++; s.flags.dd = flag(s, "dd") + 1;
  const fx: Fx = { rating: -7, boss: -9, warn: 1, stress: 15 };
  if (p.isBoss) { fx.set = { boss_dead: 1 }; fx.boss = 0; fx.team = -5; }
  s.flags.lawsuit = s.day;
  applyFx(s, fx);
  const m = `${p.name}: ${why}`;
  note(s, m);
  return m;
}

export function spendTime(s: GameState, n: number): string[] {
  const msgs: string[] = [];
  for (let i = 0; i < n; i++) {
    s.time = Math.max(0, s.time - 1);
    for (const p of [...s.queue]) {
      if (s.consult === p.id) continue;
      if (flag(s, "tutorial_lock") && p.forceId) continue;
      p.patience -= 1;
      if (p.patience <= 0) {
        s.queue = s.queue.filter((q) => q.id !== p.id);
        if (p.sev === 3) msgs.push(patientDie(s, p, "не дождался помощи из красной зоны. Это катастрофа."));
        else { applyFx(s, { rating: -1, stress: 2 }); const m = `${p.name} ушёл, не дождавшись приёма.`; note(s, m); msgs.push(m); }
      }
    }
    arrive(s);
  }
  return msgs;
}

/* ---------- consult ---------- */
export interface ConsultResult {
  outcome: "cured" | "improved" | "fail" | "harm" | "death" | "admitted";
  lines: string[]; notes: string[]; pay: number; xp: number; score: number; diagOk: boolean;
  bribe?: { amt: number; text: string; kind: "bribe" | "sick" };
}

export function conflictFor(p: Patient, s: GameState): { line: string } | null {
  if (p.conflictDone) return null;
  const chance: Partial<Record<TraitId, number>> = { aggressive: 0.7, anxious: 0.3, blogger: 0.35, chatty: 0.4, rich: 0.35, cunning: 0.3 };
  let c = chance[p.trait] ?? 0;
  if (s.staff.includes("guard")) c *= 0.6;
  if (Math.random() > c) return null;
  const lines: Record<string, string[]> = {
    aggressive: ["Вы что, издеваетесь?! Я тут два часа сижу! Где врач нормальный?!", "Мне плевать на ваши очереди! Я сейчас жалобу напишу!"],
    anxious: ["Доктор, я умираю, да? Скажите честно, это что-то страшное?!", "У меня точно что-то серьёзное, я в интернете читал(а)!"],
    blogger: ["Я снимаю для подписчиков. Улыбнитесь в камеру, доктор!", "Если мне не понравится приём, об этом узнают сто тысяч человек."],
    chatty: ["Вы знаете, доктор, вот у моей соседки была такая история... И ещё про племянника...", "А ещё расскажу про давление у тёти, это важно!"],
    rich: ["Вы знаете, кто я? Мне нужен лучший врач и без очереди.", "Я привык, чтобы меня принимали вне очереди и без лишних вопросов."],
    cunning: ["Доктор, давайте без бумажной волокиты, я спешу.", "Мне только справочку и я пойду, договоримся?"],
  };
  return { line: pick(lines[p.trait] ?? ["..."]) };
}
const CBASE: Record<string, number[]> = {
  aggressive: [0.4, 1.1, -0.8, 0.5], anxious: [1.2, -0.7, 0.3, -1.5], blogger: [0.7, 0.2, -0.2, -1.2],
  chatty: [-0.2, 0.8, 0.6, -0.4], rich: [0.5, -0.3, 0.7, -1], cunning: [0.2, 1, -0.2, 0.1],
};
export function resolveConflict(s: GameState, p: Patient, reply: number): { kind: "good" | "ok" | "bad" | "out"; text: string } {
  p.conflictDone = true;
  const base = (CBASE[p.trait] ?? [0, 0, 0, 0])[reply];
  const emp = s.skills.empathy * 0.18 * (reply === 0 || reply === 2 ? 1 : 0.4);
  const sc = base + emp + (Math.random() - 0.5) * 0.9 + (s.stress > 70 ? -0.3 : 0) + (reply === 3 && s.staff.includes("guard") ? 0.6 : 0);
  if (reply === 3 && sc > 0.2) {
    s.queue = s.queue.filter((q) => q.id !== p.id); s.consult = null;
    applyFx(s, { rating: -1, stress: -2, team: 1 });
    return { kind: "out", text: "Охрана вывела пациента из кабинета. Скандал закончился, а приём нет." };
  }
  if (sc >= 1) { s.daily.calm++; syncQuests(s); applyFx(s, { stress: -2 }); return { kind: "good", text: "Получилось! Пациент выдохнул и теперь слушает тебя внимательно." }; }
  if (sc >= 0.1) return { kind: "ok", text: "Напряжение немного спало. Можно работать." };
  applyFx(s, { stress: 7, rating: p.trait === "blogger" ? -2 : -1 });
  return { kind: "bad", text: "Не сработало. Пациент возмущён, у тебя дрожат руки." };
}

export function questionCount(s: GameState) { return 3 + Math.floor(s.skills.diag / 2) + (s.skills.diag >= 5 ? 0 : 0); }

export function doTest(s: GameState, p: Patient, t: TestId): string {
  if (p.tested.includes(t)) return "";
  p.tested.push(t);
  const free = s.staff.includes("lab") || (s.owned.includes("analyzer") && (t === "blood" || t === "rapid"));
  if (t !== "exam" && !free) spendTime(s, 1);
  if (t !== "exam") { s.daily.tests++; syncQuests(s); }
  return DIS[p.disease].find[t] ?? "Без отклонений от нормы.";
}

export function finishConsult(s: GameState, a: { pid: number; diag: string; rx: { drug: string; dose: Dose }[]; hosp: boolean; injQ: number | null; mood: number }): ConsultResult {
  const p = s.queue.find((q) => q.id === a.pid)!;
  const d = DIS[p.disease];
  const tags = patientTags(p);
  const lines: string[] = [];
  const diagOk = a.diag === p.disease;
  let harm = 0, eff = 0, extra = 0;
  for (const r of a.rx) {
    const drug = DRUG[r.drug];
    s.stock[r.drug] = Math.max(0, (s.stock[r.drug] || 0) - 1);
    const mult = r.dose === "low" ? 0.7 : r.dose === "high" ? 1.2 : 1;
    const hit = drug.contra.filter((t) => tags.includes(t));
    if (hit.length) { harm = Math.max(harm, hit.some((t) => t.startsWith("a_")) ? 2 : 1); lines.push(`${drug.name}: противопоказан этому пациенту!`); }
    if (d.bad?.includes(r.drug)) { harm = 2; lines.push(`${drug.name}: при этой болезни опасен!`); }
    if (r.dose === "high" && (p.age >= 70 || p.age < 12 || tags.includes("c_kidney"))) { harm = Math.max(harm, 1); lines.push("Двойная доза оказалась слишком тяжёлой."); }
    const e = (d.tx[r.drug] || 0) * mult;
    if (!e && !hit.length) extra += 0.06;
    eff += e;
  }
  eff = Math.max(0, Math.min(1, eff) - extra);
  let score: number;
  if (d.id === "healthy") score = a.rx.length === 0 && a.diag === "healthy" ? 1 : 0.25;
  else if (d.hosp === "must") score = a.hosp ? 0.7 + eff * 0.3 : Math.min(eff * 0.5, 0.3);
  else if (d.hosp === "good") score = eff * (a.hosp ? 1.15 : 1);
  else score = eff * (a.hosp ? 0.95 : 1);
  if (!diagOk) score *= d.hosp === "must" && a.hosp ? 0.8 : 0.55;
  if (a.injQ !== null) score += a.injQ === 2 ? 0.08 : a.injQ === 1 ? 0 : -0.1;
  score += a.mood * 0.08 + (p.trait === "anxious" ? s.skills.empathy * 0.015 : 0);
  if (harm === 1) score -= 0.25;
  score = clamp(score, 0, 1);
  if (a.injQ === 2) s.daily.perfInj++;
  s.queue = s.queue.filter((q) => q.id !== p.id);
  const msgs = spendTime(s, 1 + (p.trait === "chatty" ? 0 : 0));
  const mult = rankMult(s) * (p.trait === "rich" ? 2 : 1) * (p.vip ? 1.5 : 1);
  const pay = Math.round(d.pay * mult), xp = d.xp;
  const wasRed = p.sev === 3;
  if (a.hosp && s.ward.length < bedCap(s) && d.id !== "healthy") {
    const ip: Inpatient = { id: p.id, p, score, reward: pay, xp, days: 0, need: d.sev, treated: 0, hadHarm: harm === 2, drugs: a.rx.map((r) => r.drug) };
    s.ward.push(ip);
    note(s, `${p.name} госпитализирован.`);
    return { outcome: "admitted", lines: [...lines, "Пациент уложен в палату. Результат станет ясен через несколько смен."], notes: [], pay: 0, xp: 0, score, diagOk };
  }
  const outcome = decide(score, d.sev, harm);
  const r = settle(s, p, outcome, pay, xp, wasRed);
  const res: ConsultResult = { outcome, lines: [...lines, ...r.lines, ...msgs], notes: r.notes, pay: r.pay, xp: r.xp, score, diagOk };
  if (outcome === "cured" || outcome === "improved") {
    if (p.disease === "healthy" && Math.random() < 0.7) res.bribe = { amt: rnd(300, 700), text: `${p.name} придвигается ближе: «Подпишите больничный без осмотра, а я отблагодарю». Из кармана торчит конверт.`, kind: "sick" };
    else if ((p.trait === "rich" || p.trait === "cunning") && Math.random() < 0.28) res.bribe = { amt: rnd(400, 1200), text: `${p.name} кладёт на стол конверт: «Просто благодарность, доктор. Без вопросов».`, kind: "bribe" };
  }
  return res;
}

export function decide(score: number, sev: number, harm: number): ConsultResult["outcome"] {
  if (harm === 2) return sev >= 2 && Math.random() < 0.35 ? "death" : "harm";
  if (score >= 0.7) return "cured";
  if (score >= 0.4) return "improved";
  if (sev === 3 && Math.random() < 0.5) return "death";
  return "fail";
}

export function settle(s: GameState, p: Patient, outcome: ConsultResult["outcome"], pay: number, xp: number, wasRed: boolean): { lines: string[]; notes: string[]; pay: number; xp: number } {
  const lines: string[] = [];
  let notes: string[] = [];
  let gotPay = 0, gotXp = 0;
  const blog = p.trait === "blogger";
  const fx: Fx = {};
  if (outcome === "cured") {
    gotPay = pay; gotXp = xp; fx.money = pay; fx.xp = xp; fx.rating = 0.7 + (blog ? 2 : 0) + (p.vip ? 1 : 0); fx.stress = -1;
    s.daily.cured++; s.totals.cured++; s.daily.earned += pay;
    if (wasRed) { s.daily.red++; fx.rating = (fx.rating || 0) + 2; fx.boss = 2; }
    if (p.isBoss) { fx.set = { boss_saved: 1 }; fx.boss = 40; fx.xp = 120; }
    lines.push("Пациент здоров, спасибо вам огромное!");
    if (blog) lines.push("Блогер выложил хвалебный пост. Рейтинг растёт.");
  } else if (outcome === "improved") {
    gotPay = Math.round(pay * 0.5); gotXp = Math.round(xp * 0.5); fx.money = gotPay; fx.xp = gotXp; s.daily.earned += gotPay; s.daily.cured += 0;
    lines.push("Стало лучше, но не до конца. Пациент ушёл с лёгким недоверием.");
  } else if (outcome === "fail") {
    fx.rating = -2 - (blog ? 3 : 0); fx.xp = Math.round(xp * 0.2); fx.stress = 5;
    if (Math.random() < 0.2) fx.warn = 1;
    lines.push("Лечение не помогло. Пациент недоволен и грозится жаловаться.");
    if (blog) lines.push("Видео с вами уже в сети.");
  } else if (outcome === "harm") {
    fx.rating = -5 - (blog ? 3 : 0); fx.stress = 12; fx.money = -Math.round(pay * 0.5); fx.boss = -4;
    if (Math.random() < 0.6) fx.warn = 1;
    if (Math.random() < 0.5) s.flags.lawsuit = s.day;
    lines.push("У пациента осложнение. Придётся оплатить лечение и писать объяснительную.");
  } else {
    s.totals.deaths++; s.flags.dd = flag(s, "dd") + 1;
    fx.rating = -8 - (blog ? 3 : 0); fx.boss = -10; fx.warn = 1; fx.stress = 25; fx.team = -3;
    s.flags.lawsuit = s.day;
    if (p.isBoss) fx.set = { boss_dead: 1 };
    lines.push("Пациент не выжил. Это тяжёлый день.");
  }
  if (s.day <= 2) delete fx.warn;
  notes = applyFx(s, fx);
  note(s, `${p.name}: ${outcome === "cured" ? "вылечен" : outcome === "improved" ? "улучшение" : outcome === "fail" ? "лечение неэффективно" : outcome === "harm" ? "осложнение" : "летальный исход"}`);
  return { lines, notes, pay: gotPay, xp: gotXp };
}

export function takeBribe(s: GameState, b: { amt: number; kind: "bribe" | "sick" }): string {
  const fx: Fx = { money: b.amt, set: { corrupt: flag(s, "corrupt") + 1 }, rebel: 0 };
  let txt = "Конверт исчез в кармане халата. Совесть подала сигнал, но тихо.";
  if (b.kind === "sick") txt = "Подпись поставлена, печать на месте. Пациент счастлив, а у тебя неприятный осадок.";
  if (Math.random() < 0.22) { fx.warn = 1; fx.rating = -2; txt += " Но кто-то заметил и донёс. Выговор."; }
  fx.lev = 2;
  applyFx(s, fx);
  note(s, "Взятка принята");
  return txt;
}
export function refuseBribe(s: GameState): string {
  applyFx(s, { rating: 1, team: 1, xp: 5, stress: b0() });
  return "Ты вернула конверт. В коридоре об этом ещё долго будут шептаться с уважением.";
}
const b0 = () => 2;

/* ---------- ward ---------- */
export function wardTreat(s: GameState, id: number, mode: "drip" | "round"): string {
  const ip = s.ward.find((w) => w.id === id);
  if (!ip || ip.treated || s.time < 1) return "Нельзя.";
  spendTime(s, 1);
  ip.treated = 1;
  if (mode === "drip" && (s.stock.salin || 0) > 0) { s.stock.salin--; ip.score = clamp(ip.score + 0.12, 0, 1); return `${ip.p.name}: капельница поставлена, давление приходит в норму.`; }
  ip.score = clamp(ip.score + 0.05, 0, 1);
  return mode === "drip" ? "Физраствор закончился, ограничилась обходом." : `${ip.p.name}: обход выполнен, динамика положительная.`;
}
function dischargeWard(s: GameState, out: string[]) {
  for (const ip of [...s.ward]) {
    ip.days++;
    if (s.staff.includes("nurse_h") && !ip.treated) ip.score = clamp(ip.score + 0.03, 0, 1);
    ip.treated = 0;
    if (ip.days >= ip.need) {
      s.ward = s.ward.filter((w) => w.id !== ip.id);
      const o = decide(ip.score, ip.p.sev, ip.hadHarm ? 2 : 0);
      const r = settle(s, ip.p, o, ip.reward, ip.xp, ip.p.sev === 3);
      out.push(`Палата: ${ip.p.name} ${o === "cured" ? "выписан здоровым (+" + fmt(r.pay) + ")" : o === "improved" ? "выписан с улучшением" : o === "fail" ? "выписан без эффекта" : o === "harm" ? "перенёс осложнение" : "скончался"}.`);
    }
  }
}

/* ---------- shift cycle ---------- */
export function endShift(s: GameState) {
  const out: string[] = [];
  s.totals.shifts++;
  for (const p of [...s.queue]) {
    if (p.sev === 3) { s.queue = s.queue.filter((q) => q.id !== p.id); out.push(patientDie(s, p, "умер ночью в приёмной, пока ты спала.")); }
  }
  if (s.queue.length > 2) {
    const gone = s.queue.splice(2);
    applyFx(s, { rating: -gone.length });
    out.push(`${gone.length} пациентов ушли в другую клинику, рейтинг пострадал.`);
  }
  s.queue.forEach((p) => (p.patience = p.maxPatience));
  dischargeWard(s, out);
  const salary = RANKS[s.rank].salary;
  applyFx(s, { money: salary });
  out.push(`Зарплата: +${fmt(salary)}`);
  if (s.staff.includes("resid")) { const m = rnd(200, 400) * (1 + s.rank * 0.2); applyFx(s, { money: Math.round(m) }); out.push(`Помощник принял лёгких пациентов: +${fmt(m)}`); }
  if (flag(s, "scheme") && Math.random() < 0.4) {
    if (s.owned.includes("cam")) {
      if (!flag(s, "cam_caught")) { s.flags.cam_caught = 1; s.dossier++; out.push("Камера на складе записала, как кто-то выносит коробки. Досье +1."); }
    } else {
      const c = ["cef", "insu", "adre", "azi", "osel", "keto", "clop"].filter((k) => (s.stock[k] || 0) > 0);
      if (c.length) { const k = pick(c); const n = Math.min(s.stock[k], rnd(1, 3)); s.stock[k] -= n; s.flags.thefts = flag(s, "thefts") + n; out.push(`Со склада пропало: ${DRUG[k].name} x${n}. Кража?`); }
    }
  }
  let rest = 22 + (s.owned.includes("plants") ? 3 : 0) + (s.staff.includes("cleaner") ? 4 : 0);
  if (s.flags.overtime === s.day) rest -= 10;
  s.stress = clamp(s.stress - rest, 0, 100);
  if (s.stress >= 85) { out.push("Ты на грани выгорания. Утром придёт слабость."); }
  if (s.warn > 0 && s.day - flag(s, "lastWarn") >= 9) { s.warn--; s.flags.lastWarn = s.day; out.push("Один выговор снят за примерное поведение."); }
  if (s.rating > 45) s.rating = Math.max(45, s.rating - (s.rating - 40) * 0.07);
  if (s.day % 7 === 0 && flag(s, "dd") > 0) s.flags.dd--;
  s.day++;
  s.maxTime = maxTimeOf(s);
  s.time = s.maxTime;
  s.daily = { cured: 0, earned: 0, perfInj: 0, red: 0, tests: 0, calm: 0, quests: [] };
  newQuests(s);
  while (s.queue.length < Math.min(queueCap(s), 3)) s.queue.push(genPatient(s, { red: false }));
  if (s.day % 5 === 0) s.queue.push(genPatient(s, { red: false }));
  s.pending = pickEvents(s);
  checkOver(s);
  s.summary = out;
  s.loc = "lobby";
}

export function overtime(s: GameState): boolean {
  if (flag(s, "overtime") === s.day) return false;
  s.flags.overtime = s.day;
  s.time += 3;
  applyFx(s, { stress: 12, boss: 1 });
  return true;
}

/* ---------- events ---------- */
export function pickEvents(s: GameState): string[] {
  const res: string[] = [];
  if (s.day < 2) return res;
  const st = EVENTS.find((e) => e.story && !flag(s, "ev_" + e.id) && e.w(s) > 0);
  if (st) res.push(st.id);
  const n = Math.random() < 0.7 ? 1 : 0;
  const m = Math.random() < 0.22 ? 1 : 0;
  for (let i = 0; i < n + m; i++) {
    const cands = EVENTS.filter((e) => !e.story && !res.includes(e.id) && (!e.once || !flag(s, "ev_" + e.id)) && s.day - flag(s, "evd_" + e.id) >= 6 && e.w(s) > 0);
    const tot = cands.reduce((a, e) => a + e.w(s), 0);
    if (!tot) break;
    let r = Math.random() * tot;
    for (const e of cands) { r -= e.w(s); if (r <= 0) { res.push(e.id); break; } }
  }
  return res;
}
export function choicesOf(s: GameState, id: string): Choice[] {
  const e = EVENTS.find((x) => x.id === id)!;
  return typeof e.choices === "function" ? e.choices(s) : e.choices;
}
export function choiceReason(s: GameState, c: Choice): string | null {
  const n = c.need;
  if (!n) return null;
  if (n.money && s.money < n.money) return `Нужно ${fmt(n.money)}`;
  if (n.dossier && s.dossier < n.dossier) return `Досье ${n.dossier}+`;
  if (n.diplo && s.skills.diplo < n.diplo) return `Дипломатия ${n.diplo}+`;
  if (n.team && s.rel.team < n.team) return `Коллектив ${n.team}+`;
  if (n.boss && s.rel.boss < n.boss) return `Доверие Громова ${n.boss}+`;
  if (n.lev && s.rel.lev < n.lev) return `Доверие Левицкого ${n.lev}+`;
  if (n.flag && !flag(s, n.flag)) return "Недоступно";
  if (n.rank && s.rank < n.rank) return "Нужен ранг выше";
  return null;
}
export function resolveChoice(s: GameState, evId: string, idx: number): { text: string; notes: string[] } {
  const c = choicesOf(s, evId)[idx];
  const e = EVENTS.find((x) => x.id === evId)!;
  s.flags["ev_" + evId] = 1; s.flags["evd_" + evId] = s.day;
  let text = c.res;
  let fx = c.fx;
  if (c.risk && Math.random() < c.risk.p) { fx = c.risk.fx; text = c.risk.res; }
  const notes = applyFx(s, fx);
  note(s, `${e.title}: ${c.t}`);
  return { text, notes };
}

/* ---------- admin / promotion ---------- */
export function examReqs(s: GameState): { label: string; ok: boolean }[] {
  const i = s.rank, nx = RANKS[i + 1];
  if (!nx) return [];
  const sup = Math.max(s.rel.boss, s.rel.lev, s.rel.team);
  return [
    { label: `Опыт ${s.xp} из ${nx.xp}`, ok: s.xp >= nx.xp },
    { label: `Рейтинг больницы не ниже ${25 + 6 * i}`, ok: s.rating >= 25 + 6 * i },
    { label: "Не более одного выговора", ok: s.warn <= 1 },
    { label: `Покровитель (доверие ${12 + 8 * i}+) или досье ${2 + i}+`, ok: sup >= 12 + 8 * i || s.dossier >= 2 + i },
  ];
}
export function promote(s: GameState): string[] {
  s.rank++; s.sp += 2;
  const o = [`Теперь ты: ${RANKS[s.rank].name}`, "Получено 2 очка навыков."];
  const fx = applyFx(s, { rating: 2, stress: -8 });
  return [...o, ...fx];
}

export interface AdminDef { id: string; name: string; desc: string; cost: number; money?: number; sign?: string; need?: () => void }
export const ADMIN_ACTIONS: AdminDef[] = [
  { id: "flat_boss", name: "Польстить Громову", desc: "Расспросить о молодости и восхититься его опытом.", cost: 1 },
  { id: "flat_lev", name: "Задобрить Левицкого", desc: "Улыбаться, кивать и просить совета.", cost: 1 },
  { id: "gossip", name: "Чай с Зинаидой", desc: "Узнать новости и сплетни.", cost: 1 },
  { id: "spy", name: "Покопаться в бумагах", desc: "Тайно собрать досье на Левицкого.", cost: 1 },
  { id: "rally", name: "Собрать коллектив", desc: "Угостить коллег и поговорить о проблемах.", cost: 1, money: 300 },
  { id: "raise", name: "Просить прибавку", desc: "Рискнуть поговорить с Громовым о деньгах.", cost: 1 },
  { id: "complain", name: "Анонимная жалоба в министерство", desc: "Скрытно сообщить о хищениях. Нужно досье 3+ и подпись.", cost: 1, sign: "Анонимное заявление в министерство здравоохранения" },
];
export function adminAction(s: GameState, id: string): { ok: boolean; text: string; notes: string[] } {
  const def = ADMIN_ACTIONS.find((a) => a.id === id)!;
  if (s.time < def.cost) return { ok: false, text: "Смена закончилась. Силы на исходе.", notes: [] };
  if (flag(s, "adm_" + id) === s.day) return { ok: false, text: "Сегодня ты это уже делала. Нужно время.", notes: [] };
  if (def.money && s.money < def.money) return { ok: false, text: `Не хватает денег: нужно ${def.money}.`, notes: [] };
  if (id === "complain" && s.dossier < 3) return { ok: false, text: "Без доказательств жалоба развалится. Нужно досье 3+.", notes: [] };
  s.flags["adm_" + id] = s.day;
  spendTime(s, def.cost);
  let fx: Fx = {}; let text = "";
  const r = Math.random();
  switch (id) {
    case "flat_boss":
      if (s.path.flat >= 10 && r < 0.35) { fx = { boss: -6, flat: 1, stress: 3 }; text = "Громов прищурился: «Деточка, лесть не заменяет диагноз». Подхалимство слишком очевидно."; }
      else { fx = { boss: 4, flat: 1, team: -1 }; text = "Громов расцвёл и рассказал историю про 1987 год. Он тебя запомнил, коллеги тоже закатили глаза."; }
      break;
    case "flat_lev": fx = { lev: 5, flat: 1, boss: -1 }; text = "Левицкий похлопал тебя по плечу: «Далеко пойдёшь». Взгляд у него был очень внимательный."; break;
    case "gossip":
      if (r < 0.45) { fx = { nurse: 3, dossier: 1 }; text = "Зинаида шепнула, в какие дни пропадали ампулы и кто держал ключи от склада. Ты всё записала."; }
      else { fx = { nurse: 2, stress: -4 }; text = "Чай, булочки и час сплетен про всех. Нервы отдохнули, Зинаида оттаяла."; }
      break;
    case "spy":
      if (r < 0.5) { fx = { dossier: 1, whistle: 1 }; text = "В нижнем ящике нашлась накладная с двойной ценой. Копия в кармане."; }
      else if (r < 0.78) { fx = { stress: 4 }; text = "Только пыль и степлеры. Но сердце колотилось."; }
      else { fx = { lev: -15, stress: 8, boss: -2 }; text = "Левицкий застал тебя у ящика. Его улыбка не изменилась, но температура в кабинете упала на десять градусов."; }
      break;
    case "rally": fx = { money: -300, team: 6, rebel: 1 }; text = "Пиццу съели за минуту. Коллеги жаловались на задержки зарплаты и обещали поддержать тебя."; break;
    case "raise":
      if (s.rel.boss >= 30) { fx = { money: RANKS[s.rank].salary * 2, boss: -2 }; text = "Громов вздохнул и подписал премию. «Заслужила. Но не наглей»."; }
      else { fx = { boss: -5, stress: 5 }; text = "«Сначала заслужи, потом проси», отрезал Громов."; }
      break;
    case "complain":
      fx = { dossier: -2, whistle: 3, set: { complaint_sent: 1 } }; text = "Письмо ушло без обратного адреса. Теперь остаётся ждать реакции сверху.";
      if (Math.random() < 0.3) { fx = { ...fx, lev: -20, stress: 8 }; text += " Левицкий почему-то стал смотреть на тебя иначе. Утечка?"; }
      break;
  }
  const notes = applyFx(s, fx);
  note(s, def.name);
  return { ok: true, text, notes };
}

/* ---------- quests / cash ---------- */
export function newQuests(s: GameState) {
  const pool = QUESTS.filter((q) => (q.rank ?? 0) <= s.rank);
  const ids: string[] = [];
  while (ids.length < 3 && pool.length > ids.length) { const q = pick(pool); if (!ids.includes(q.id)) ids.push(q.id); }
  s.daily.quests = ids.map((id) => ({ id, done: false, claimed: false }));
}
export function syncQuests(s: GameState) {
  for (const q of s.daily.quests) {
    const def = QUESTS.find((x) => x.id === q.id)!;
    if (s.daily[def.k] >= def.n) q.done = true;
  }
}
export function claimQuest(s: GameState, id: string) {
  const q = s.daily.quests.find((x) => x.id === id);
  const def = QUESTS.find((x) => x.id === id);
  if (!q || !def || !q.done || q.claimed) return;
  q.claimed = true;
  applyFx(s, { money: def.money, xp: def.xp });
}
export function cashRate(s: GameState) { return s.rating * 0.06 + s.rank * 1.5 + (s.staff.includes("nurse_h") ? 3 : 0) + (s.staff.includes("lab") ? 2 : 0) + (s.staff.includes("resid") ? 6 : 0); }
export function tickCash(s: GameState, now: number) {
  const dt = Math.max(0, now - s.cashT) / 60000;
  const rate = cashRate(s);
  s.cash = Math.min(rate * 240, s.cash + rate * dt);
  s.cashT = now;
}
export function collectCash(s: GameState): number {
  const m = Math.floor(s.cash);
  if (m <= 0) return 0;
  s.cash -= m;
  applyFx(s, { money: m });
  s.daily.earned += m;
  return m;
}

/* ---------- shop ---------- */
export function buyDrug(s: GameState, id: string, n: number, mult = 1): boolean {
  const cost = DRUG[id].price * n * mult;
  if (s.money < cost) return false;
  s.money -= cost; s.stock[id] = (s.stock[id] || 0) + n;
  return true;
}
export function buyItem(s: GameState, id: string): string {
  const it = SHOP.find((x) => x.id === id)!;
  if (s.money < it.price) return "Не хватает денег.";
  if (it.cat !== "svc") {
    if (it.cat === "staff" ? s.staff.includes(id) : s.owned.includes(id)) return "Уже куплено.";
    if (it.req && !s.owned.includes(it.req)) return "Сначала купи предыдущее.";
  }
  s.money -= it.price;
  if (it.cat === "staff") s.staff.push(id); else if (it.cat !== "svc") s.owned.push(id);
  if (it.fx) applyFx(s, it.fx);
  if (id === "coffee") s.maxTime = maxTimeOf(s);
  note(s, `Куплено: ${it.name}`);
  return "ok";
}

export function spendSkill(s: GameState, k: keyof GameState["skills"]) {
  if (s.sp < 1 || s.skills[k] >= 5) return;
  s.sp--; s.skills[k]++;
}
export const _unused = DRUGS;
