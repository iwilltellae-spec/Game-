"use client";
import { useEffect, useRef, useState } from "react";
import type { GameState, Choice } from "../types";
import { EVENTS } from "../events";
import { act } from "../store";
import { INTRO, NPC_NAME, TIPS, RANKS } from "../data";
import { choicesOf, choiceReason, resolveChoice, endShift, overtime, flag, genPatient, rnd } from "../engine";
import { Icon, Face, Sprite } from "./ui";

/* ---------------- signature ---------------- */
export function SignaturePad({ onDone, label = "Подписать" }: { onDone: (data: string) => void; label?: string }) {
  const ref = useRef<HTMLCanvasElement>(null);
  const [len, setLen] = useState(0);
  const last = useRef<{ x: number; y: number } | null>(null);
  const pos = (e: React.PointerEvent) => {
    const c = ref.current!, r = c.getBoundingClientRect();
    return { x: ((e.clientX - r.left) / r.width) * c.width, y: ((e.clientY - r.top) / r.height) * c.height };
  };
  const down = (e: React.PointerEvent) => { (e.target as Element).setPointerCapture(e.pointerId); last.current = pos(e); };
  const move = (e: React.PointerEvent) => {
    if (!last.current) return;
    const p = pos(e), ctx = ref.current!.getContext("2d")!;
    ctx.strokeStyle = "#1b2a6b"; ctx.lineWidth = 3.2; ctx.lineCap = "round"; ctx.lineJoin = "round";
    ctx.beginPath(); ctx.moveTo(last.current.x, last.current.y); ctx.lineTo(p.x, p.y); ctx.stroke();
    setLen((l) => l + Math.hypot(p.x - last.current!.x, p.y - last.current!.y));
    last.current = p;
  };
  const up = () => { last.current = null; };
  const clear = () => { const c = ref.current!; c.getContext("2d")!.clearRect(0, 0, c.width, c.height); setLen(0); };
  return (
    <div>
      <div style={{ border: "3px dashed #8aa0c8", borderRadius: 12, background: "#fff", touchAction: "none", position: "relative" }}>
        <canvas ref={ref} width={360} height={140} style={{ width: "100%", height: 120, display: "block", touchAction: "none" }} onPointerDown={down} onPointerMove={move} onPointerUp={up} onPointerCancel={up} />
        {len < 5 && <span style={{ position: "absolute", left: 0, right: 0, top: "42%", textAlign: "center", color: "#a9b6cf", fontWeight: 700, pointerEvents: "none" }}>Распишись пальцем здесь</span>}
      </div>
      <div style={{ display: "flex", gap: 8, marginTop: 8 }}>
        <button className="btn white sm" onClick={clear}>Стереть</button>
        <button className="btn block" disabled={len < 60} onClick={() => onDone(ref.current!.toDataURL("image/png"))}><Icon n="pen" s={18} />{label}</button>
      </div>
    </div>
  );
}

export function SignDoc({ title, onSigned, onCancel }: { title: string; onSigned: (sig: string) => void; onCancel?: () => void }) {
  const [sig, setSig] = useState<string | null>(null);
  return (
    <div className="overlay center" style={{ zIndex: 80 }}>
      <div className="modal">
        <div className="paper">
          <div style={{ fontWeight: 800, fontSize: 13, textTransform: "uppercase", color: "#7a6a2a" }}>Документ</div>
          <div style={{ fontWeight: 800, fontSize: 16, margin: "4px 0 6px" }}>{title}</div>
          <div style={{ fontSize: 12, color: "#6b6234", minHeight: 24 }}>Подпись ставится собственноручно. Последствия подписи необратимы.</div>
          <div style={{ display: "flex", alignItems: "flex-end", justifyContent: "space-between", minHeight: 74, marginTop: 6 }}>
            {sig ? <img className="sigimg" src={sig} alt="" /> : <span style={{ color: "#b9ad7d", fontSize: 12 }}>Место для подписи</span>}
            {sig && <div className="stamp">БОЛЬНИЦА<br />СВ. АННЫ<br />№13</div>}
          </div>
        </div>
        <div style={{ marginTop: 10 }}>
          {!sig ? <SignaturePad onDone={(d) => { setSig(d); setTimeout(() => onSigned(d), 900); }} /> : <div style={{ textAlign: "center", fontWeight: 800, color: "#2c8f2f" }}>Подписано и скреплено печатью</div>}
          {!sig && onCancel && <button className="btn white sm block" style={{ marginTop: 8 }} onClick={onCancel}>Передумать</button>}
        </div>
      </div>
    </div>
  );
}

/* ---------------- tips ---------------- */
export function Tip({ k, style }: { k: string; style?: React.CSSProperties }) {
  const t = TIPS[k];
  return (
    <div className="card" style={{ display: "flex", gap: 8, alignItems: "center", borderColor: "#ffc61a", background: "#fff9df", boxShadow: "0 3px 0 #ffc61a", padding: 7, ...style }}>
      <Face img={t.who} size={44} />
      <div style={{ flex: 1, fontSize: 12, fontWeight: 600, lineHeight: 1.25 }}>{t.text}</div>
      <button className="btn yellow sm" onClick={() => act((s) => { s.tips[k] = 1; })}>Ясно</button>
    </div>
  );
}

/* ---------------- injection mini game ---------------- */
export function InjectionGame({ hands, nurse, onDone }: { hands: number; nurse: number; onDone: (q: number) => void }) {
  const [mode, setMode] = useState<"choose" | "play" | "done">("choose");
  const [pos, setPos] = useState(0);
  const [res, setRes] = useState<number | null>(null);
  const zone = useRef({ c: 30 + Math.random() * 40, g: 8 + hands * 2.5 });
  const raf = useRef(0);
  const t0 = useRef(0);
  useEffect(() => {
    if (mode !== "play") return;
    t0.current = performance.now();
    const loop = (t: number) => { setPos(50 + 50 * Math.sin((t - t0.current) * 0.0042)); raf.current = requestAnimationFrame(loop); };
    raf.current = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf.current);
  }, [mode]);
  const stop = () => {
    cancelAnimationFrame(raf.current);
    const d = Math.abs(pos - zone.current.c);
    const q = d <= zone.current.g ? 2 : d <= zone.current.g + 12 ? 1 : 0;
    setRes(q); setMode("done"); setTimeout(() => onDone(q), 1100);
  };
  const delegate = () => {
    const r = Math.random() - nurse / 400;
    const q = r < 0.22 ? 0 : r < 0.8 ? 1 : 2;
    setRes(q); setMode("done"); setTimeout(() => onDone(q), 1000);
  };
  const { c, g } = zone.current;
  return (
    <div>
      <div style={{ fontWeight: 800, fontSize: 16, marginBottom: 6 }}>Укол</div>
      {mode === "choose" && (
        <div style={{ display: "grid", gap: 8 }}>
          <button className="btn" onClick={() => setMode("play")}><Icon n="syringe" s={18} />Сделать самой</button>
          <button className="btn white" onClick={delegate}>Поручить медсестре</button>
          <div style={{ fontSize: 12, color: "#51627f" }}>Сама: останови стрелку в зелёной зоне. Медсестра: результат случаен, чем лучше с ней отношения, тем надёжнее.</div>
        </div>
      )}
      {mode !== "choose" && (
        <div>
          <div style={{ position: "relative", height: 34, borderRadius: 12, background: "#ffd0d0", border: "3px solid #23324d", overflow: "hidden" }}>
            <div style={{ position: "absolute", top: 0, bottom: 0, left: `${c - g - 12}%`, width: `${(g + 12) * 2}%`, background: "#ffe37a" }} />
            <div style={{ position: "absolute", top: 0, bottom: 0, left: `${c - g}%`, width: `${g * 2}%`, background: "#58d64d" }} />
            <div style={{ position: "absolute", top: -2, bottom: -2, left: `${mode === "done" && res !== null && mode ? pos : pos}%`, width: 6, marginLeft: -3, background: "#23324d", borderRadius: 3 }} />
          </div>
          {mode === "play" && <button className="btn red block" style={{ marginTop: 10, padding: 14, fontSize: 17 }} onClick={stop}>Колоть!</button>}
          {mode === "done" && <div style={{ marginTop: 10, textAlign: "center", fontWeight: 800, fontSize: 17, color: res === 2 ? "#2c8f2f" : res === 1 ? "#b8860b" : "#c62828" }}>{res === 2 ? "Идеально! Пациент даже не заметил." : res === 1 ? "Нормально. Чуть больно, но терпимо." : "Промах! Синяк и недовольство."}</div>}
        </div>
      )}
    </div>
  );
}

/* ---------------- intro / tutorial ---------------- */
export function Intro({ s }: { s: GameState }) {
  const [i, setI] = useState(0);
  const [name, setName] = useState(s.name || "");
  const [sig, setSig] = useState<string | null>(s.sig);
  const finish = () => act((g) => {
    g.name = name.trim() || "Алиса"; g.sig = sig; g.started = true; g.intro = 99;
    const p = genPatient(g, { disease: "sprain", portrait: "p4" });
    p.trait = "calm"; p.allergy = null; p.chronic = null; p.patience = 99; p.maxPatience = 99;
    g.queue = [p];
  });
  const total = INTRO.length + 4;
  const slide = INTRO[i - 1];
  const sprite = i === 0 ? "hero1" : i <= INTRO.length ? slide.who : i === INTRO.length + 3 ? "boss" : "hero0";
  return (
    <div className="overlay" style={{ zIndex: 95, background: "linear-gradient(#bfe8f5,#f9c9d4)", flexDirection: "column", alignItems: "stretch" }}>
      <img src="/bg/lobby.webp" alt="" style={{ position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: "cover", opacity: 0.55 }} />
      <div style={{ position: "relative", flex: 1, display: "flex", flexDirection: "column", padding: 14, minHeight: 0 }}>
        {i === 0 && (
          <div style={{ textAlign: "center", paddingTop: 8 }}>
            <div style={{ display: "inline-flex", alignItems: "center", gap: 8, background: "#fff", border: "4px solid #ef4444", borderRadius: 16, padding: "2px 12px", color: "#ef4444" }}><Icon n="cross" s={22} /><b style={{ fontSize: 12, letterSpacing: 1 }}>ГОРОДСКАЯ БОЛЬНИЦА №13</b></div>
            <div style={{ fontSize: 46, fontWeight: 800, lineHeight: 1, marginTop: 8, color: "#fff", WebkitTextStroke: "3px #1e6fd0", paintOrder: "stroke fill", textShadow: "0 5px 0 #0f4a9c" }}>БЕЛЫЙ ХАЛАТ</div>
            <div style={{ fontWeight: 700, color: "#23324d", marginTop: 6 }}>Путь от практиканта до главного врача</div>
          </div>
        )}
        <div style={{ flex: 1, display: "flex", alignItems: "flex-end", justifyContent: "center", minHeight: 0 }}>
          <Sprite key={sprite} img={sprite} className="npc-in" style={{ height: i === 0 ? "88%" : "92%", objectFit: "contain", filter: "drop-shadow(0 8px 0 rgba(0,0,0,.15))" }} />
        </div>
        <div className="modal" key={i} style={{ marginTop: 10, flex: "none" }}>
          {i === 0 && (<><div style={{ fontSize: 14, lineHeight: 1.35 }}>Ты только что получила диплом и пришла в больницу, где пропадают лекарства, а за креслом главврача идёт тихая война. Лечи людей, принимай решения, плети союзы или иди своим путём.</div><button className="btn block" style={{ marginTop: 10, padding: 13 }} onClick={() => setI(1)}>Начать карьеру</button></>)}
          {i >= 1 && i <= INTRO.length && (<><div style={{ fontWeight: 800, color: "#1e6fd0", marginBottom: 3 }}>{NPC_NAME[slide.who]}</div><div style={{ fontSize: 14, lineHeight: 1.35 }}>{slide.text}</div><button className="btn block" style={{ marginTop: 10 }} onClick={() => setI(i + 1)}>Дальше</button></>)}
          {i === INTRO.length + 1 && (<><div style={{ fontWeight: 800, marginBottom: 6 }}>Как тебя зовут, доктор?</div><input value={name} maxLength={14} onChange={(e) => setName(e.target.value)} placeholder="Алиса" style={{ width: "100%", padding: 12, borderRadius: 12, border: "3px solid #1e6fd0", font: "inherit", fontSize: 16, fontWeight: 700, outline: "none", userSelect: "text" }} /><button className="btn block" style={{ marginTop: 10 }} onClick={() => setI(i + 1)}>Это моё имя</button></>)}
          {i === INTRO.length + 2 && (<><div style={{ fontWeight: 800, marginBottom: 2 }}>Твоя подпись</div><div style={{ fontSize: 12, color: "#51627f", marginBottom: 6 }}>Врач подписывает каждый рецепт. Придумай свою подпись, она появится на всех документах.</div><SignaturePad label="Сохранить подпись" onDone={(d) => { setSig(d); setI(i + 1); }} /></>)}
          {i === INTRO.length + 3 && (<><div style={{ fontWeight: 800, color: "#1e6fd0", marginBottom: 4 }}>Правила игры</div><ul style={{ margin: 0, paddingLeft: 18, fontSize: 13, lineHeight: 1.4 }}><li>Смена длится 12 часов. Приём и обследования тратят часы.</li><li>Пациенты в красной рамке не ждут: промедление смертельно.</li><li>Расспроси, обследуй, поставь диагноз, назначь препараты. Проверяй аллергию!</li><li>Деньги, связи и досье открывают путь наверх. Льсти, интригуй или иди своим путём.</li></ul><button className="btn block" style={{ marginTop: 10, padding: 13 }} onClick={finish}>Начать первую смену</button></>)}
          <div style={{ display: "flex", gap: 4, justifyContent: "center", marginTop: 10 }}>{Array.from({ length: total }).map((_, k) => <i key={k} style={{ width: 8, height: 8, borderRadius: 4, background: k <= i ? "#1e6fd0" : "#cfd8e6" }} />)}</div>
        </div>
      </div>
    </div>
  );
}

/* ---------------- events ---------------- */
export function EventModal({ s }: { s: GameState }) {
  const ev = EVENTS.find((e) => e.id === s.pending[0]);
  const [res, setRes] = useState<{ text: string; notes: string[] } | null>(null);
  const [signIdx, setSignIdx] = useState<number | null>(null);
  useEffect(() => { if (!ev) act((g) => { g.pending.shift(); }); }, [ev]);
  if (!ev) return null;
  const choices = choicesOf(s, ev.id);
  const text = typeof ev.text === "function" ? ev.text(s) : ev.text;
  const img = ev.who === "sys" ? null : ev.who === "team" ? "max" : ev.who;
  const choose = (idx: number) => {
    let out: { text: string; notes: string[] } = { text: "", notes: [] };
    act((g) => { out = resolveChoice(g, ev.id, idx); });
    setRes(out);
  };
  const next = () => { setRes(null); act((g) => { g.pending.shift(); }); };
  return (
    <div className="overlay center" style={{ zIndex: 70, flexDirection: "column", justifyContent: "flex-end", padding: 0 }}>
      <div style={{ flex: 1, width: "100%", display: "flex", alignItems: "flex-end", justifyContent: "center", minHeight: 0, paddingTop: 50 }}>
        {img && <Sprite key={ev.id} img={img} className="npc-in" style={{ height: "95%", objectFit: "contain", filter: "drop-shadow(0 8px 0 rgba(0,0,0,.2))" }} />}
        {!img && <div style={{ color: "#fff", opacity: 0.9 }}><Icon n="cross" s={110} /></div>}
      </div>
      <div className="modal" style={{ borderRadius: "24px 24px 0 0", maxHeight: "62%", width: "100%" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 4 }}>
          <span className="chip" style={{ background: ev.story ? "#ffe9a8" : "#e8eef8" }}>{ev.story ? "Сюжет" : "Событие"}</span>
          <b style={{ fontSize: 17 }}>{ev.title}</b>
        </div>
        <div style={{ fontSize: 12, fontWeight: 800, color: "#1e6fd0", marginBottom: 2 }}>{NPC_NAME[ev.who] ?? ""}</div>
        {!res ? (
          <>
            <div style={{ fontSize: 13.5, lineHeight: 1.38, marginBottom: 10 }}>{text}</div>
            <div style={{ display: "grid", gap: 7 }}>
              {choices.map((c: Choice, k: number) => {
                const why = choiceReason(s, c);
                return (
                  <button key={k} className={`btn ${why ? "white" : "blue"}`} style={{ justifyContent: "flex-start", textAlign: "left", fontSize: 13 }} disabled={!!why} onClick={() => (c.sign ? setSignIdx(k) : choose(k))}>
                    {c.sign && <Icon n="pen" s={16} />}<span style={{ flex: 1 }}>{c.t}</span>{why && <span style={{ fontSize: 10.5, opacity: 0.8 }}>{why}</span>}
                  </button>
                );
              })}
            </div>
          </>
        ) : (
          <>
            <div style={{ fontSize: 13.5, lineHeight: 1.38, marginBottom: 8 }}>{res.text}</div>
            <div style={{ display: "flex", flexWrap: "wrap", gap: 5, marginBottom: 10 }}>{res.notes.map((n, k) => <span key={k} className={`chip ${/\+|▲|снят/.test(n) && !/Выговор$/.test(n) ? "good" : /-|▼|Выговор|Нервы \+/.test(n) ? "bad" : ""}`}>{n}</span>)}</div>
            <button className="btn block" onClick={next}>Дальше</button>
          </>
        )}
      </div>
      {signIdx !== null && <SignDoc title={choices[signIdx].sign!} onCancel={() => setSignIdx(null)} onSigned={() => { const k = signIdx; setSignIdx(null); choose(k); }} />}
    </div>
  );
}

/* ---------------- summary / shift end / game over ---------------- */
export function SummaryModal({ s }: { s: GameState }) {
  return (
    <div className="overlay center" style={{ zIndex: 75 }}>
      <div className="modal">
        <div style={{ textAlign: "center", fontWeight: 800, fontSize: 20, color: "#1e6fd0" }}>Новый день: {s.day}</div>
        <div style={{ textAlign: "center", fontSize: 12, color: "#51627f", marginBottom: 8 }}>{RANKS[s.rank].name}</div>
        <div style={{ display: "grid", gap: 5, margin: "8px 0 12px" }}>
          {s.summary!.map((l, k) => <div key={k} className="card" style={{ padding: "6px 9px", fontSize: 12.5, borderColor: /пропало|умер|скончал|Кража/.test(l) ? "#ffb4b4" : "#d6e0f0", animation: `pop .35s ${k * 0.07}s both` }}>{l}</div>)}
        </div>
        <button className="btn block" onClick={() => act((g) => { g.summary = null; })}>В больницу</button>
      </div>
    </div>
  );
}
export function ShiftEnd({ s, forced, onClose }: { s: GameState; forced: boolean; onClose: () => void }) {
  const canOT = flag(s, "overtime") !== s.day;
  return (
    <div className="overlay center" style={{ zIndex: 72 }}>
      <div className="modal">
        <div style={{ fontWeight: 800, fontSize: 19 }}>{forced ? "Смена окончена" : "Закончить смену?"}</div>
        <div style={{ fontSize: 13, margin: "6px 0 10px", lineHeight: 1.35 }}>
          {forced ? "Силы на исходе, рабочий день закончился." : `Осталось часов: ${s.time}.`} В очереди ждут: {s.queue.length}. {s.queue.some((p) => p.sev === 3) ? "Красные пациенты не доживут до утра!" : "Остальные подождут до завтра, но недовольные уйдут."}
        </div>
        <div style={{ display: "grid", gap: 8 }}>
          <button className="btn blue" onClick={() => { onClose(); act((g) => endShift(g)); }}>Идти домой и закончить смену</button>
          {canOT && <button className="btn yellow" onClick={() => { act((g) => { overtime(g); }); onClose(); }}>Остаться на ночь (+3 ч, нервы +12)</button>}
          {!forced && <button className="btn white" onClick={onClose}>Продолжить работу</button>}
        </div>
      </div>
    </div>
  );
}
export function GameOver({ s, onNew }: { s: GameState; onNew: () => void }) {
  return (
    <div className="overlay center" style={{ zIndex: 99, background: "rgba(10,10,25,.92)" }}>
      <div className="modal" style={{ textAlign: "center" }}>
        <div style={{ color: "#c62828" }}><Icon n="skull" s={54} /></div>
        <div style={{ fontWeight: 800, fontSize: 24, margin: "4px 0" }}>Увольнение</div>
        <div style={{ fontSize: 14, lineHeight: 1.4, marginBottom: 10 }}>{s.over!.text}</div>
        <div className="card" style={{ fontSize: 13, textAlign: "left", marginBottom: 12 }}>
          <div>Должность: <b>{RANKS[s.rank].name}</b></div>
          <div>Дней в больнице: <b>{s.day}</b></div>
          <div>Вылечено пациентов: <b>{s.totals.cured}</b></div>
          <div>Потеряно пациентов: <b>{s.totals.deaths}</b></div>
        </div>
        <div style={{ fontSize: 12, color: "#51627f", marginBottom: 10 }}>Новая карьера: ты сохраняешь подпись и получаешь бонус опыта прошлой жизни (+300 к стартовым деньгам за каждую попытку).</div>
        <button className="btn block" onClick={onNew}>Начать новую карьеру</button>
      </div>
    </div>
  );
}
export const _r = rnd;
