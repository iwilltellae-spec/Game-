"use client";
import type { ReactNode, CSSProperties } from "react";

const P: Record<string, ReactNode> = {
  cross: <path d="M9 3h6v6h6v6h-6v6H9v-6H3V9h6z" fill="currentColor" stroke="none" />,
  money: <><rect x="2" y="6" width="20" height="12" rx="2" /><circle cx="12" cy="12" r="3" /><path d="M5.5 9.5v5M18.5 9.5v5" /></>,
  clock: <><circle cx="12" cy="12" r="9" /><path d="M12 7v5l3 2" /></>,
  map: <><path d="M12 2a7 7 0 0 0-7 7c0 5 7 13 7 13s7-8 7-13a7 7 0 0 0-7-7z" /><circle cx="12" cy="9" r="2.5" /></>,
  gear: <><circle cx="12" cy="12" r="3" /><circle cx="12" cy="12" r="8" strokeDasharray="3.2 2.3" strokeWidth="3.4" /></>,
  star: <path d="M12 2.5l2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.4 6.1 20.5l1.2-6.5L2.5 9.4l6.6-.9z" fill="currentColor" />,
  heart: <path d="M12 21s-8-5.5-8-11a4.5 4.5 0 0 1 8-2.8A4.5 4.5 0 0 1 20 10c0 5.5-8 11-8 11z" fill="currentColor" />,
  person: <><circle cx="12" cy="8" r="4" fill="currentColor" /><path d="M4 21c0-4.5 3.5-7 8-7s8 2.5 8 7z" fill="currentColor" /></>,
  home: <path d="M3 11l9-8 9 8v10h-6v-6H9v6H3z" fill="currentColor" />,
  stetho: <><path d="M6 3v6a4 4 0 0 0 8 0V3" /><path d="M10 13v2a5 5 0 0 0 10 0v-1.5" /><circle cx="20" cy="12" r="2" /></>,
  bed: <><path d="M3 19V6M3 15h18v4M21 15v-3a3 3 0 0 0-3-3h-7v6" /><circle cx="7" cy="11" r="2" /></>,
  pill: <g transform="rotate(-45 12 12)"><rect x="3" y="8" width="18" height="8" rx="4" /><path d="M12 8v8" /></g>,
  brief: <><rect x="3" y="7" width="18" height="13" rx="2" /><path d="M9 7V4h6v3M3 13h18" /></>,
  syringe: <><path d="M4 20l5-5M14 5l5 5M11 8l5 5-6 6-5-5z" /><path d="M16 3l5 5" /></>,
  clip: <><rect x="5" y="4" width="14" height="17" rx="2" /><path d="M9 4h6v3H9zM8 12h8M8 16h6" /></>,
  drop: <path d="M12 3s6 6.5 6 11a6 6 0 0 1-12 0c0-4.5 6-11 6-11z" fill="currentColor" />,
  bone: <path d="M7 7a2 2 0 1 1 3 1l6 6a2 2 0 1 1 1 3 2 2 0 1 1-3-1l-6-6a2 2 0 1 1-1-3z" />,
  wave: <path d="M2 12h4l2-6 4 12 3-9 2 3h5" />,
  close: <path d="M5 5l14 14M19 5L5 19" strokeWidth="3.4" />,
  check: <path d="M4 12l5 5 11-11" strokeWidth="3.4" />,
  lock: <><rect x="5" y="11" width="14" height="10" rx="2" /><path d="M8 11V8a4 4 0 0 1 8 0v3" /></>,
  pen: <path d="M3 21l4-1 12-12-3-3L4 17zM14 6l3 3" />,
  shield: <path d="M12 2l8 3v6c0 5-3.5 9-8 11-4.5-2-8-6-8-11V5z" fill="currentColor" />,
  eye: <><path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z" /><circle cx="12" cy="12" r="3" /></>,
  chat: <path d="M4 5h16v11H9l-5 4z" />,
  book: <><path d="M4 4h7a3 3 0 0 1 3 3v13a3 3 0 0 0-3-3H4zM20 4h-6" /><path d="M20 4v13h-6" /></>,
  bolt: <path d="M13 2L4 14h7l-1 8 9-12h-7z" fill="currentColor" />,
  skull: <><path d="M12 3a8 8 0 0 0-8 8c0 3 1.5 4.5 3 5.5V20h10v-3.5c1.5-1 3-2.5 3-5.5a8 8 0 0 0-8-8z" /><circle cx="9" cy="11" r="1.5" fill="currentColor" /><circle cx="15" cy="11" r="1.5" fill="currentColor" /></>,
  plus: <path d="M12 5v14M5 12h14" strokeWidth="3.4" />,
  back: <path d="M15 5l-7 7 7 7" strokeWidth="3.4" />,
};
export function Icon({ n, s = 22, c }: { n: string; s?: number; c?: string }) {
  return (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.3" strokeLinecap="round" strokeLinejoin="round" style={{ color: c, flex: "none" }}>
      {P[n] ?? P.cross}
    </svg>
  );
}

export function Pill({ icon, bg, children, fill, fillBg, onClick, style }: { icon: string; bg: string; children: ReactNode; fill?: number; fillBg?: string; onClick?: () => void; style?: CSSProperties }) {
  return (
    <div className="pill" onClick={onClick} style={{ cursor: onClick ? "pointer" : "default", ...style }}>
      <span className="ico" style={{ background: bg }}><Icon n={icon} s={17} /></span>
      {fill !== undefined && <span className="fill" style={{ width: `calc(${Math.max(0, Math.min(1, fill)) * 100}% - 28px)`, background: fillBg }} />}
      <span className="txt">{children}</span>
    </div>
  );
}

export function Sheet({ title, onClose, children, size = "h80", right }: { title: ReactNode; onClose?: () => void; children: ReactNode; size?: "h66" | "h80" | "auto"; right?: ReactNode }) {
  return (
    <div className="overlay" onClick={(e) => { if (e.target === e.currentTarget && onClose) onClose(); }}>
      <div className={`sheet ${size === "auto" ? "" : size}`} style={size === "auto" ? { maxHeight: "92%" } : undefined}>
        <div className="sheet-h">
          <span style={{ fontSize: 16 }}>{title}</span>
          <span style={{ display: "flex", gap: 8, alignItems: "center" }}>
            {right}
            {onClose && <button className="btn red sm" style={{ padding: "3px 8px" }} onClick={onClose} aria-label="Закрыть"><Icon n="close" s={16} /></button>}
          </span>
        </div>
        <div className="sheet-b">{children}</div>
      </div>
    </div>
  );
}

export function Bar({ v, color = "#4ccb40", h = 10 }: { v: number; color?: string; h?: number }) {
  return <div className="bar" style={{ height: h }}><i style={{ width: `${Math.max(0, Math.min(1, v)) * 100}%`, background: color }} /></div>;
}

export function Face({ img, size = 52, ring, className }: { img: string; size?: number; ring?: string; className?: string }) {
  return (
    <div className={`${ring ?? ""} ${className ?? ""}`} style={{ width: size, height: size, borderRadius: 14, overflow: "hidden", background: "linear-gradient(#e6f4ff,#c7e4f7)", border: "3px solid #fff", boxShadow: "0 0 0 3px #23324d", flex: "none", position: "relative" }}>
      <img src={`/chars/${img}.webp`} alt="" loading="lazy" decoding="async" style={{ position: "absolute", top: 2, left: "50%", width: "170%", transform: "translateX(-50%)", maxWidth: "none" }} />
    </div>
  );
}

export function Sprite({ img, className, style }: { img: string; className?: string; style?: CSSProperties }) {
  return <img src={`/chars/${img}.webp`} alt="" decoding="async" className={className} style={style} />;
}
export const fmt = (n: number) => Math.round(n).toLocaleString("ru-RU");
