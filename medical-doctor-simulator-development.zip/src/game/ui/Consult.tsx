"use client";
import { useEffect, useState } from "react";
import type { GameState, Patient, Dose, TestId } from "../types";
import { act } from "../store";
import { DIS, DRUGS, DRUG, TESTS, FORM_NAME, ALLERGY_NAME, CHRONIC_NAME, patientTags } from "../meds";
import { TRAIT_INFO } from "../data";
import { conflictFor, resolveConflict, questionCount, doTest, finishConsult, bedCap, buyDrug, takeBribe, refuseBribe, note, type ConsultResult } from "../engine";
import { Sheet, Icon, Face, fmt } from "./ui";
import { Tip, InjectionGame } from "./Overlays";

type Stage = "conflict" | "talk" | "diag" | "rx" | "inj" | "result";
const QS = ["Где и как болит?", "Когда это началось?", "Что ещё беспокоит?", "Есть ли аллергия?", "Хронические болезни?", "Что принимали сами?"];
const VAGUE = ["Ну... болит. Просто болит.", "Не помню точно. Давно.", "Да ничего особенного, доктор."];
const SELF = ["Пил(а) чай с малиной, не помогло.", "Ничего не принимал(а), сразу к вам.", "Съел(а) какую-то таблетку, не помню какую.", "Мазал(а) бабушкиной мазью."];

function answer(p: Patient, q: number, s: GameState): string {
  const d = DIS[p.disease];
  if (q < 3) {
    if (p.trait === "stoic" && (p.id + q) % 2 === 0 && s.skills.diag < 3) return VAGUE[(p.id + q) % 3];
    return d.hints[q];
  }
  if (q === 3) return p.allergy ? `Да, у меня аллергия: ${ALLERGY_NAME[p.allergy]}.` : "Аллергии нет, никогда не замечал(а).";
  if (q === 4) return p.chronic ? (p.chronic === "c_preg" ? "Я беременна." : `Да, есть: ${CHRONIC_NAME[p.chronic]}.`) : "Хронических болезней нет.";
  return SELF[p.id % 4];
}
function seeded(id: number, n: number) { let x = id * 9301 + n * 49297 + 233; x = (x * 9301 + 49297) % 233280; return x / 233280; }

export function Consult({ s }: { s: GameState }) {
  const live = s.queue.find((q) => q.id === s.consult);
  const [p0] = useState<Patient | undefined>(live);
  const p = live ?? p0;
  const [conflict] = useState(() => (p && !p.conflictDone ? conflictFor(p, s) : null));
  const [stage, setStage] = useState<Stage>(conflict ? "conflict" : "talk");
  const [cres, setCres] = useState<{ kind: string; text: string } | null>(null);
  const [mood, setMood] = useState(0);
  const [tab, setTab] = useState<"ask" | "test">("ask");
  const [diag, setDiag] = useState<string | null>(null);
  const [sel, setSel] = useState<{ drug: string; dose: Dose }[]>([]);
  const [hosp, setHosp] = useState(false);
  const [signed, setSigned] = useState(false);
  const [stamped, setStamped] = useState(false);
  const [result, setResult] = useState<ConsultResult | null>(null);
  const [bribeTxt, setBribeTxt] = useState<string | null>(null);

  useEffect(() => { if (p && !p.conflictDone && !conflict) act((g) => { const x = g.queue.find((q) => q.id === p.id); if (x) x.conflictDone = true; }); }, [p, conflict]);
  if (!p) return null;
  const d = DIS[p.disease];
  const limit = questionCount(s);
  const used = p.asked.length;
  const bedsFree = bedCap(s) - s.ward.length;

  const options = (() => {
    const ds = [d.id, ...d.sim.filter((x) => x !== d.id)].slice(0, 4);
    if (d.id !== "healthy" && seeded(p.id, 1) < 0.25) ds[3] = "healthy";
    if (!ds.includes(d.id)) ds[0] = d.id;
    return ds.map((id, i) => ({ id, k: seeded(p.id, i + 7) })).sort((a, b) => a.k - b.k).map((x) => x.id);
  })();

  const step = ["conflict", "talk", "diag", "rx", "result"] as Stage[];
  const titleOf: Record<Stage, string> = { conflict: "Конфликт", talk: "Осмотр", diag: "Диагноз", rx: "Рецепт", inj: "Укол", result: "Итог" };
  const stIdx = step.indexOf(stage === "inj" ? "rx" : stage);

  const askQ = (q: number) => act((g) => { const x = g.queue.find((y) => y.id === p.id); if (x && !x.asked.includes(q) && x.asked.length < questionCount(g)) x.asked.push(q); });
  const test = (t: TestId) => act((g) => { const x = g.queue.find((y) => y.id === p.id); if (x) doTest(g, x, t); });
  const knownTags = new Set<string>([...(p.age < 12 ? ["child"] : []), ...(p.asked.includes(3) && p.allergy ? [p.allergy] : []), ...(p.asked.includes(4) && p.chronic ? [p.chronic] : [])]);
  const stockOf = (id: string) => s.stock[id] || 0;
  const toggle = (id: string) => setSel((cur) => (cur.find((x) => x.drug === id) ? cur.filter((x) => x.drug !== id) : cur.length >= 2 ? cur : [...cur, { drug: id, dose: "norm" as Dose }]));
  const needInj = sel.some((x) => DRUG[x.drug].form === "inj");

  const submit = (injQ: number | null) => {
    let r: ConsultResult | null = null;
    act((g) => { r = finishConsult(g, { pid: p.id, diag: diag!, rx: sel, hosp, injQ, mood }); });
    setResult(r); setStage("result");
  };
  const close = () => act((g) => { g.consult = null; g.loc = "lobby"; });
  const postpone = () => act((g) => { g.consult = null; g.loc = "lobby"; });

  const notes: { k: string; who: string; text: string }[] = [{ k: "c", who: "p", text: d.complaint }];
  p.asked.forEach((q) => notes.push({ k: "q" + q, who: "q", text: `${QS[q]} ${answer(p, q, s)}` }));
  p.tested.forEach((t) => notes.push({ k: "t" + t, who: "t", text: `${TESTS.find((x) => x.id === t)!.name}: ${d.find[t] ?? "Без отклонений от нормы."}` }));

  const notesBox = (max?: number) => (
    <div className="card" style={{ background: "#fffdf3", borderColor: "#eadfae", boxShadow: "0 3px 0 #eadfae", maxHeight: max, overflowY: "auto", display: "grid", gap: 5, flex: max ? "none" : 1, minHeight: 60 }}>
      {notes.map((n) => (
        <div key={n.k} style={{ fontSize: 12.5, lineHeight: 1.3, display: "flex", gap: 6, animation: "pop .3s both" }}>
          <span style={{ flex: "none", marginTop: 1, color: n.who === "t" ? "#1e6fd0" : n.who === "p" ? "#c62828" : "#2c8f2f" }}><Icon n={n.who === "t" ? "clip" : n.who === "p" ? "chat" : "eye"} s={14} /></span>
          <span style={{ fontWeight: n.who === "p" ? 700 : 500 }}>{n.who === "p" ? `«${n.text}»` : n.text}</span>
        </div>
      ))}
    </div>
  );

  const title = (
    <span style={{ display: "flex", alignItems: "center", gap: 8 }}>
      <span>{titleOf[stage]}</span>
      <span style={{ display: "flex", gap: 3 }}>{step.filter((x) => x !== "conflict" || conflict).map((x, i) => <i key={x} style={{ width: 16, height: 6, borderRadius: 3, background: i <= stIdx ? "#ffd23f" : "#ffffff55" }} />)}</span>
    </span>
  );

  return (
    <Sheet title={title} size="h66" right={stage !== "result" && <button className="btn white sm" style={{ padding: "3px 8px" }} onClick={postpone}>Отложить</button>}>
      <div style={{ display: "flex", flexDirection: "column", gap: 8, height: "100%" }}>
        <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
          <Face img={p.portrait} size={46} ring={p.sev === 3 ? "ring-r" : p.sev === 2 ? "ring-y" : "ring-g"} />
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontWeight: 800, fontSize: 14 }}>{p.name}, {p.age < 2 ? "младенец" : `${p.age} лет`}</div>
            <div style={{ fontSize: 11.5, color: "#51627f" }}>{TRAIT_INFO[p.trait].name}. {TRAIT_INFO[p.trait].hint}</div>
          </div>
          <div style={{ fontSize: 11, fontWeight: 800, textAlign: "right", color: p.sev === 3 ? "#c62828" : "#51627f" }}>{p.sev === 3 ? "КРАСНАЯ ЛИНИЯ" : p.sev === 2 ? "Срочно" : "Планово"}</div>
        </div>

        {stage === "conflict" && conflict && (
          <>
            <div className="card" style={{ borderColor: "#ffb4b4", background: "#fff4f4", fontWeight: 700 }}>«{conflict.line}»</div>
            {!cres ? (
              <div style={{ display: "grid", gap: 7, gridTemplateColumns: "1fr 1fr" }}>
                {["Успокоить", "Строго осадить", "Пошутить", "Позвать охрану"].map((t, i) => (
                  <button key={i} className={`btn ${i === 3 ? "red" : "blue"}`} onClick={() => {
                    let r = { kind: "ok", text: "" };
                    act((g) => { const x = g.queue.find((y) => y.id === p.id)!; r = resolveConflict(g, x, i); if (r.kind === "out") note(g, r.text); });
                    setCres(r); setMood(r.kind === "good" ? 1 : r.kind === "bad" ? -1 : 0);
                  }}>{t}</button>
                ))}
              </div>
            ) : (
              <>
                <div className="card" style={{ fontWeight: 700, borderColor: cres.kind === "bad" ? "#ffb4b4" : "#b9e8b0" }}>{cres.text}</div>
                {cres.kind !== "out" && <button className="btn block" onClick={() => setStage("talk")}>Приступить к осмотру</button>}
                {cres.kind === "out" && <button className="btn block" onClick={close}>Закрыть</button>}
              </>
            )}
          </>
        )}

        {stage === "talk" && (
          <>
            {!s.tips.talk ? <Tip k="talk" /> : !s.tips.allergy && <Tip k="allergy" />}
            {notesBox()}
            <div style={{ display: "flex", gap: 6 }}>
              <button className={`btn sm ${tab === "ask" ? "blue" : "white"}`} style={{ flex: 1 }} onClick={() => setTab("ask")}>Расспросить ({used}/{limit})</button>
              <button className={`btn sm ${tab === "test" ? "blue" : "white"}`} style={{ flex: 1 }} onClick={() => setTab("test")}>Обследовать</button>
            </div>
            {tab === "ask" ? (
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 6 }}>
                {QS.map((q, i) => <button key={i} className="btn white sm" style={{ fontSize: 12, justifyContent: "flex-start", textAlign: "left" }} disabled={p.asked.includes(i) || used >= limit} onClick={() => askQ(i)}>{p.asked.includes(i) ? <Icon n="check" s={14} /> : null}{q}</button>)}
              </div>
            ) : (
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 6 }}>
                {TESTS.map((t) => {
                  const lock = t.need && !s.owned.includes(t.need);
                  const free = t.id === "exam" || s.staff.includes("lab") || (s.owned.includes("analyzer") && (t.id === "blood" || t.id === "rapid"));
                  const done = p.tested.includes(t.id);
                  return (
                    <button key={t.id} className="btn white sm" style={{ flexDirection: "column", gap: 2, fontSize: 12, padding: "6px 4px" }} disabled={!!lock || done || (!free && s.time < 1)} onClick={() => test(t.id)}>
                      <Icon n={lock ? "lock" : done ? "check" : t.icon} s={18} />{t.name}
                      <span style={{ fontSize: 10, opacity: 0.7 }}>{lock ? "нет аппарата" : done ? "готово" : free ? "0 ч" : "1 ч"}</span>
                    </button>
                  );
                })}
              </div>
            )}
            <button className="btn block" onClick={() => setStage("diag")}>Поставить диагноз</button>
          </>
        )}

        {stage === "diag" && (
          <>
            {!s.tips.diag && <Tip k="diag" />}
            {notesBox(110)}
            <div style={{ display: "grid", gap: 7 }}>
              {options.map((id) => (
                <button key={id} className={`card ${diag === id ? "sel" : ""}`} style={{ textAlign: "left", font: "inherit", fontWeight: 800, cursor: "pointer", display: "flex", alignItems: "center", gap: 8 }} onClick={() => setDiag(id)}>
                  <span style={{ width: 22, height: 22, borderRadius: 11, border: "3px solid #1e6fd0", background: diag === id ? "#1e6fd0" : "#fff", flex: "none" }} />{DIS[id].name}
                </button>
              ))}
            </div>
            <div style={{ display: "flex", gap: 6 }}>
              <button className="btn white" onClick={() => setStage("talk")}>Назад</button>
              <button className="btn block" disabled={!diag} onClick={() => setStage("rx")}>Назначить лечение</button>
            </div>
          </>
        )}

        {stage === "rx" && diag && (
          <>
            {!s.tips.rx && <Tip k="rx" />}
            <div className="paper" style={{ fontSize: 12.5 }}>
              <b>Рецепт.</b> {p.name}, {p.age} л. Диагноз: <b>{DIS[diag].name}</b>.
              <div style={{ fontWeight: 700, color: sel.length ? "#1d6b1b" : "#8a7d4a" }}>{sel.length ? sel.map((x) => `${DRUG[x.drug].name} (${x.dose === "low" ? "мало" : x.dose === "high" ? "много" : "норма"})`).join(", ") : "Препараты не выбраны (до двух)"}</div>
            </div>
            <div style={{ display: "grid", gap: 6 }}>
              {[...DRUGS].sort((a, b) => (s.skills.pharm >= 2 ? (DIS[diag].tx[b.id] ? 1 : 0) - (DIS[diag].tx[a.id] ? 1 : 0) : 0)).map((dr) => {
                const on = sel.find((x) => x.drug === dr.id);
                const warn = dr.contra.some((t) => knownTags.has(t));
                const eff = DIS[diag].tx[dr.id] || 0;
                const st = stockOf(dr.id);
                return (
                  <div key={dr.id} className={`card ${on ? "sel" : ""}`} style={{ padding: 7 }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 7 }} onClick={() => (st > 0 ? toggle(dr.id) : undefined)}>
                      <span style={{ width: 28, height: 28, borderRadius: 9, background: on ? "#1e6fd0" : "#e3ebf8", color: on ? "#fff" : "#1e6fd0", display: "grid", placeItems: "center", flex: "none" }}><Icon n={dr.form === "inj" ? "syringe" : dr.form === "drip" ? "drop" : "pill"} s={16} /></span>
                      <div style={{ flex: 1, minWidth: 0 }}>
                        <div style={{ fontWeight: 800, fontSize: 13 }}>{dr.name} {warn && <span style={{ color: "#c62828", fontSize: 11 }}>противопоказан!</span>}</div>
                        <div style={{ fontSize: 10.5, color: "#51627f" }}>{dr.kind}, {FORM_NAME[dr.form]}{s.skills.pharm >= 2 && eff > 0 ? <b style={{ color: "#2c8f2f" }}> · подходит{s.skills.pharm >= 4 ? " " + "●".repeat(Math.ceil(eff * 3)) : ""}</b> : ""}</div>
                      </div>
                      {st > 0 ? <span style={{ fontSize: 12, fontWeight: 800 }}>{st} шт</span> : <button className="btn yellow sm" onClick={(e) => { e.stopPropagation(); act((g) => { buyDrug(g, dr.id, 1, 2); }); }}>Срочно {fmt(dr.price * 2)}</button>}
                    </div>
                    {on && (
                      <div style={{ display: "flex", gap: 5, marginTop: 6 }}>
                        {(["low", "norm", "high"] as Dose[]).map((dd) => <button key={dd} className={`btn sm ${on.dose === dd ? "blue" : "white"}`} style={{ flex: 1 }} onClick={() => setSel((c) => c.map((x) => (x.drug === dr.id ? { ...x, dose: dd } : x)))}>{dd === "low" ? "Мало" : dd === "norm" ? "Норма" : "Много"}</button>)}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
            <button className={`card ${hosp ? "sel" : ""}`} disabled={bedsFree <= 0} style={{ textAlign: "left", font: "inherit", fontWeight: 800, cursor: "pointer", opacity: bedsFree <= 0 ? 0.5 : 1 }} onClick={() => setHosp(!hosp)}>
              <Icon n="bed" s={16} /> Госпитализировать <span style={{ fontSize: 11, fontWeight: 600, color: "#51627f" }}>(свободных коек: {Math.max(0, bedsFree)})</span>{hosp && <b style={{ float: "right", color: "#1e6fd0" }}>ДА</b>}
            </button>
            <div className="paper" style={{ display: "flex", alignItems: "center", justifyContent: "space-between", minHeight: 82 }}>
              <div style={{ minHeight: 48, display: "flex", alignItems: "center" }}>{signed && s.sig ? <img className="sigimg" src={s.sig} alt="подпись" /> : <span style={{ fontSize: 12, color: "#a39a6b" }}>Подпись врача</span>}</div>
              {stamped && <div className="stamp">ВЫДАНО<br />ВРАЧ<br />{s.name.toUpperCase().slice(0, 9)}</div>}
            </div>
            <div style={{ display: "flex", gap: 6 }}>
              <button className="btn white sm" onClick={() => setStage("diag")}>Назад</button>
              <button className="btn blue" style={{ flex: 1 }} disabled={signed} onClick={() => setSigned(true)}><Icon n="pen" s={16} />Подписать</button>
              <button className="btn red" style={{ flex: 1 }} disabled={!signed || stamped} onClick={() => setStamped(true)}>Печать</button>
            </div>
            <button className="btn block" disabled={!stamped} style={{ padding: 13 }} onClick={() => (needInj ? setStage("inj") : submit(null))}>{sel.length ? "Выдать рецепт" : "Выдать без назначений"}</button>
          </>
        )}

        {stage === "inj" && (
          <>
            {!s.tips.inj && <Tip k="inj" />}
            <InjectionGame hands={s.skills.hands} nurse={s.rel.nurse} onDone={(q) => submit(q)} />
          </>
        )}

        {stage === "result" && result && (
          <>
            <div className="card" style={{ textAlign: "center", borderColor: ["cured"].includes(result.outcome) ? "#8fdc86" : ["harm", "death", "fail"].includes(result.outcome) ? "#ffb4b4" : "#bcd0f0" }}>
              <div style={{ fontWeight: 800, fontSize: 20, color: result.outcome === "cured" ? "#2c8f2f" : result.outcome === "improved" || result.outcome === "admitted" ? "#1e6fd0" : "#c62828" }}>
                {{ cured: "Пациент вылечен", improved: "Состояние улучшилось", fail: "Лечение не помогло", harm: "Осложнение", death: "Летальный исход", admitted: "Пациент в палате" }[result.outcome]}
              </div>
              <div style={{ fontSize: 12, color: "#51627f", marginBottom: 4 }}>{result.diagOk ? "Диагноз поставлен верно." : `Диагноз был ошибочным. На самом деле: ${d.name}.`}</div>
              {result.lines.map((l, i) => <div key={i} style={{ fontSize: 13, marginTop: 3 }}>{l}</div>)}
            </div>
            <div style={{ display: "flex", flexWrap: "wrap", gap: 5, justifyContent: "center" }}>
              {result.notes.map((n, k) => <span key={k} className={`chip ${/\+|▲/.test(n) && !/Выговор/.test(n) ? "good" : /-|▼|Выговор|Нервы/.test(n) ? "bad" : ""}`} style={{ animationDelay: `${k * 0.08}s` }}>{n}</span>)}
            </div>
            {result.bribe && !bribeTxt && (
              <div className="card" style={{ borderColor: "#ffc61a", background: "#fff9df" }}>
                <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 7 }}>{result.bribe.text}</div>
                <div style={{ display: "flex", gap: 6 }}>
                  <button className="btn red sm" style={{ flex: 1 }} onClick={() => { let t = ""; act((g) => { t = takeBribe(g, result.bribe!); }); setBribeTxt(t); }}>Взять {fmt(result.bribe.amt)}</button>
                  <button className="btn sm" style={{ flex: 1 }} onClick={() => { let t = ""; act((g) => { t = refuseBribe(g); }); setBribeTxt(t); }}>Отказаться</button>
                </div>
              </div>
            )}
            {bribeTxt && <div className="card" style={{ fontSize: 13 }}>{bribeTxt}</div>}
            <button className="btn block" disabled={!!result.bribe && !bribeTxt} style={{ padding: 13 }} onClick={close}>Готово</button>
          </>
        )}
      </div>
    </Sheet>
  );
}
