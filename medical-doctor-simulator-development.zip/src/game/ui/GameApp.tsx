"use client";
import { useEffect, useMemo, useState } from "react";
import type { Loc, Patient } from "../types";
import { loadGame, useGame, act, newCareer } from "../store";
import { RANKS, NPC_NAME, totalRate } from "../data";
import { DIS } from "../meds";
import { collectCash, tickCash, syncQuests, bedCap, spendTime, genPatient, queueCap } from "../engine";
import { Icon, Pill, Face, Sprite, Bar, fmt } from "./ui";
import { Intro, EventModal, SummaryModal, ShiftEnd, GameOver, Tip } from "./Overlays";
import { Consult } from "./Consult";
import { WardDock, ShopSheet, AdminSheet, ProfileSheet, MapSheet, MenuSheet } from "./Panels";

const BG: Record<Loc, string> = { lobby: "lobby", office: "office", ward: "ward", shop: "office", admin: "admin" };
const NAV: { k: Loc; n: string; i: string }[] = [
  { k: "lobby", n: "Приёмная", i: "home" },
  { k: "office", n: "Кабинет", i: "stetho" },
  { k: "ward", n: "Палата", i: "bed" },
  { k: "shop", n: "Аптека", i: "pill" },
  { k: "admin", n: "Дирекция", i: "brief" },
];
type Sheet = null | "map" | "profile" | "skills" | "menu" | "shop" | "admin" | "tasks" | "shiftend";

export default function GameApp() {
  const s = useGame();
  const [sheet, setSheet] = useState<Sheet>(null);
  const [selId, setSelId] = useState<number | null>(null);
  const [coins, setCoins] = useState<{ id: number; t: string }[]>([]);

  useEffect(() => { loadGame(); }, []);
  useEffect(() => {
    const t = setInterval(() => act((g) => { tickCash(g, Date.now()); }), 5000);
    return () => clearInterval(t);
  }, []);
  useEffect(() => {
    if (!s?.toast) return;
    const t = setTimeout(() => act((g) => { g.toast = null; }), 2600);
    return () => clearTimeout(t);
  }, [s?.toast]);
  useEffect(() => {
    ["lobby", "office", "ward", "admin"].forEach((n) => { const i = new Image(); i.src = `/bg/${n}.webp`; });
    ["hero0", "hero1", "hero2", "boss", "lev", "nurse", "rival", "max", "inspector"].forEach((n) => { const i = new Image(); i.src = `/chars/${n}.webp`; });
  }, []);

  const sorted = useMemo(() => (s ? [...s.queue].sort((a, b) => b.sev - a.sev || a.patience - b.patience) : []), [s]);
  if (!s) return <div className="app" style={{ display: "grid", placeItems: "center", background: "#bfe8f5", color: "#1e6fd0" }}><Icon n="cross" s={64} /></div>;

  const rank = RANKS[s.rank], nx = RANKS[s.rank + 1];
  const loc = s.loc;
  const inConsult = s.consult !== null;
  const sel: Patient | undefined = s.queue.find((p) => p.id === selId) ?? sorted[0];
  const consultP = s.queue.find((p) => p.id === s.consult);
  const hour = 8 + (s.maxTime - s.time);
  const claim = s.daily.quests.filter((q) => q.done && !q.claimed).length;
  const redN = s.queue.filter((p) => p.sev === 3).length;
  const go = (l: Loc) => act((g) => { if (g.consult === null) g.loc = l; });
  const blocking = !!s.over || !s.started || !!s.summary || s.pending.length > 0;
  const forced = s.time <= 0 && s.consult === null && s.started && !blocking;

  const rightImg = loc === "lobby" ? sel?.portrait : loc === "office" ? consultP?.portrait ?? (s.consult !== null ? undefined : undefined) : loc === "admin" ? (s.flags.boss_dead ? "lev" : "boss") : "nurse";
  const rightKey = `${loc}-${loc === "lobby" ? sel?.id : consultP?.id}`;
  const bubble = (() => {
    if (inConsult) return null;
    if (loc === "lobby") return sel ? DIS[sel.disease].complaint : "В приёмной пока никого. Загляни позже или оформи кассу.";
    if (loc === "office") return "Кабинет готов. Приглашай пациентов из приёмной.";
    if (loc === "ward") return s.ward.length ? "Они на тебя надеются. Не забывай про обход." : "Палата пуста. Госпитализируй тяжёлых пациентов.";
    if (loc === "shop") return "На складе всё считается. Почти всё.";
    const b = s.rel.boss;
    return s.flags.boss_dead ? "Левицкий занял кабинет. «Присаживайся, поговорим»." : b > 30 ? "Рад тебя видеть. Что новенького?" : b < -15 ? "Я тобой недоволен. Исправляйся." : "Работаешь? Работай.";
  })();

  const collect = () => {
    const amt = Math.floor(s.cash);
    if (amt < 1) return;
    act((g) => { collectCash(g); });
    const id = Date.now(); setCoins((c) => [...c, { id, t: `+${fmt(amt)}` }]);
    setTimeout(() => setCoins((c) => c.filter((x) => x.id !== id)), 1000);
  };
  const accept = (p: Patient) => act((g) => { if (g.time < 1 || g.consult !== null) return; g.consult = p.id; g.loc = "office"; syncQuests(g); });

  return (
    <div className="app">
      {/* top bar */}
      <div className="topbar">
        <button className="mapbtn" onClick={() => setSheet("map")} aria-label="Карта"><Icon n="map" s={26} /></button>
        <div style={{ flex: 1, display: "grid", gap: 6, minWidth: 0 }}>
          <Pill icon="money" bg="#2faa3a">{fmt(s.money)}</Pill>
          <Pill icon="clock" bg="#e08a00" onClick={() => setSheet("shiftend")}>День {s.day} · {String(hour).padStart(2, "0")}:00</Pill>
        </div>
        <div style={{ flex: 1, display: "grid", gap: 6, minWidth: 0 }}>
          <Pill icon="person" bg="#e0447c" fill={nx ? (s.xp - rank.xp) / Math.max(1, nx.xp - rank.xp) : 1} fillBg="#ff9fc2" onClick={() => setSheet("profile")}>{rank.name.split(" ")[0]}</Pill>
          <Pill icon="star" bg="#f59e0b" onClick={() => setSheet("profile")}>{Math.round(s.rating)} · выг. {s.warn}/3</Pill>
        </div>
        <button className="sidebtn" style={{ background: "#8e9bb3", width: 38, height: 38 }} onClick={() => setSheet("menu")} aria-label="Меню"><Icon n="gear" s={22} /></button>
      </div>
      <div style={{ display: "flex", gap: 8, padding: "4px 10px", background: "#fff", borderBottom: "3px solid #e3e9f3", zIndex: 29, alignItems: "center" }}>
        <span style={{ color: "#e08a00" }}><Icon n="clock" s={15} /></span>
        <div style={{ flex: 1 }}><Bar v={s.time / s.maxTime} color="#ffc61a" h={9} /></div>
        <span style={{ fontSize: 11, fontWeight: 800, width: 42, textAlign: "center" }}>{s.time} ч</span>
        <span style={{ color: "#ef4444" }}><Icon n="heart" s={15} /></span>
        <div style={{ flex: 1 }}><Bar v={s.stress / 100} color={s.stress > 70 ? "#ef4444" : "#fb7185"} h={9} /></div>
      </div>

      {/* scene */}
      <div className="scene">
        <img key={loc} className="scene-bg" src={`/bg/${BG[loc]}.webp`} alt="" style={{ filter: loc === "shop" ? "hue-rotate(115deg) saturate(1.15)" : undefined }} />
        <div className={`chars ${inConsult ? "compact" : "normal"}`}>
          <div className="slot"><Sprite key={rank.tier} img={`hero${rank.tier}`} className="hero-idle" /></div>
          <div className="slot" style={{ height: "100%" }}>
            {rightImg && <Sprite key={rightKey} img={rightImg} className="npc-in" style={{ height: loc === "admin" || loc === "ward" || loc === "shop" ? "86%" : "74%" }} />}
          </div>
        </div>
        {bubble && !inConsult && <div className="bubble" key={bubble} style={{ right: 10, top: "5%", maxWidth: "52%" }}>{bubble}</div>}

        {/* side buttons */}
        {!inConsult && (
          <div style={{ position: "absolute", left: 8, top: 10, display: "grid", gap: 10, zIndex: 12 }}>
            <button className="sidebtn" style={{ background: "linear-gradient(#7fe66f,#3fb934)" }} onClick={() => setSheet("tasks")} aria-label="Задания"><Icon n="clip" s={24} />{claim > 0 && <span className="badge">{claim}</span>}</button>
            <button className="sidebtn" style={{ background: "linear-gradient(#5aaeff,#1e6fd0)" }} onClick={() => setSheet("skills")} aria-label="Навыки"><Icon n="star" s={24} />{s.sp > 0 && <span className="badge">{s.sp}</span>}</button>
          </div>
        )}
        {loc === "lobby" && !inConsult && (
          <button onClick={collect} aria-label="Касса" style={{ position: "absolute", right: 8, top: "26%", zIndex: 12, background: "transparent", border: 0, cursor: "pointer", font: "inherit" }}>
            <div style={{ position: "relative", width: 74, textAlign: "center" }}>
              <svg viewBox="0 0 80 60" width="74" style={{ animation: s.cash >= 1 ? "pulse 1.3s infinite" : undefined }}>
                <rect x="6" y="28" width="68" height="28" rx="6" fill="#c98a4b" stroke="#6b4423" strokeWidth="3" />
                <rect x="14" y="14" width="52" height="24" rx="4" fill="#5bd64d" stroke="#2c8f2f" strokeWidth="3" transform="rotate(-4 40 26)" />
                <circle cx="40" cy="26" r="7" fill="#b5f0a8" stroke="#2c8f2f" strokeWidth="2.5" />
                <rect x="30" y="38" width="20" height="6" rx="2" fill="#6b4423" />
              </svg>
              <div style={{ background: "#fff", border: "3px solid #23324d", borderRadius: 10, fontWeight: 800, fontSize: 12, padding: "1px 4px", marginTop: -4 }}>{fmt(s.cash)}</div>
              <div style={{ fontSize: 10, fontWeight: 800, color: "#23324d", textShadow: "0 0 3px #fff, 0 0 3px #fff" }}>+{totalRate(s)}/мин</div>
              {coins.map((c) => <span key={c.id} className="floatcoin" style={{ left: 14, top: 0 }}>{c.t}</span>)}
            </div>
          </button>
        )}

        {/* dock */}
        {!inConsult && (
          <div className="dock" key={loc}>
            {loc === "lobby" && (
              <div style={{ display: "grid", gap: 7 }}>
                {!s.tips.queue && <Tip k="queue" />}
                <div style={{ display: "grid", gridTemplateColumns: `repeat(${Math.min(6, Math.max(4, s.queue.length))}, 1fr)`, gap: 5 }}>
                  {sorted.map((p) => (
                    <button key={p.id} onClick={() => setSelId(p.id)} style={{ background: sel?.id === p.id ? "#fff3c4" : "#fff", border: sel?.id === p.id ? "3px solid #ffc61a" : "3px solid #d6e0f0", borderRadius: 14, padding: 3, cursor: "pointer", display: "grid", gap: 3, justifyItems: "center", font: "inherit" }}>
                      <Face img={p.portrait} size={46} ring={p.sev === 3 ? "ring-r" : p.sev === 2 ? "ring-y" : "ring-g"} className={p.patience <= 2 ? "shake" : ""} />
                      <div style={{ width: "100%" }}><Bar v={p.patience / p.maxPatience} color={p.sev === 3 ? "#ef4444" : p.sev === 2 ? "#ffc61a" : "#4ccb40"} h={6} /></div>
                      <span style={{ fontSize: 9.5, fontWeight: 800, color: p.sev === 3 ? "#c62828" : "#23324d", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis", maxWidth: "100%" }}>{p.sev === 3 ? "КРАСНАЯ" : p.name.split(" ")[1] ?? p.name.split(" ")[0]}</span>
                    </button>
                  ))}
                  {Array.from({ length: Math.max(0, Math.min(6, Math.max(4, s.queue.length)) - sorted.length) }).map((_, i) => <div key={i} style={{ border: "3px dashed #cdd8ea", borderRadius: 14, minHeight: 74, display: "grid", placeItems: "center", color: "#cdd8ea" }}><Icon n="person" s={22} /></div>)}
                </div>
                {sel ? (
                  <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ fontWeight: 800, fontSize: 13.5 }}>{sel.name}, {sel.age < 2 ? "младенец" : `${sel.age} л.`}</div>
                      <div style={{ fontSize: 11.5, color: sel.sev === 3 ? "#c62828" : "#51627f", fontWeight: sel.sev === 3 ? 800 : 500 }}>{sel.sev === 3 ? `Красная линия! Ждёт ещё ${sel.patience} ч` : `Терпения: ${sel.patience} ч`}</div>
                    </div>
                    <button className={`btn ${sel.sev === 3 ? "red" : ""}`} disabled={s.time < 1 || s.consult !== null} onClick={() => accept(sel)} style={{ padding: "11px 16px" }}>{s.time < 1 ? "Нет сил" : "Принять"}</button>
                  </div>
                ) : (
                  <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
                    <div style={{ flex: 1, fontSize: 12.5, color: "#51627f" }}>Очередь пуста. Пациенты приходят по мере течения времени.</div>
                    <button className="btn blue" disabled={s.time < 1} onClick={() => act((g) => { spendTime(g, 1); if (!g.queue.length && g.queue.length < queueCap(g)) g.queue.push(genPatient(g, {})); })}>Ждать час</button>
                  </div>
                )}
              </div>
            )}
            {loc === "office" && (
              <div style={{ display: "grid", gap: 8 }}>
                <div style={{ fontWeight: 800 }}>Кабинет свободен</div>
                <div style={{ fontSize: 12.5, color: "#51627f" }}>В очереди ждут: {s.queue.length}. {redN ? `Красная линия: ${redN}!` : ""}</div>
                <button className="btn" onClick={() => go("lobby")}>В приёмную за пациентом</button>
              </div>
            )}
            {loc === "ward" && <WardDock s={s} />}
            {loc === "shop" && (
              <div style={{ display: "grid", gap: 8 }}>
                {!s.tips.shop && <Tip k="shop" />}
                <div style={{ fontSize: 12.5, color: "#51627f" }}>Закончились: <b>{Object.entries(s.stock).filter(([, v]) => v === 0).length}</b> препаратов. Коек: {bedCap(s)}.</div>
                <button className="btn" style={{ padding: 13 }} onClick={() => setSheet("shop")}><Icon n="pill" s={20} />Открыть склад и магазин</button>
              </div>
            )}
            {loc === "admin" && (
              <div style={{ display: "grid", gap: 8 }}>
                <div style={{ display: "flex", gap: 6, justifyContent: "space-between" }}>
                  {(["boss", "lev", "nurse", "rival", "team"] as const).map((k) => { const v = s.rel[k]; return <div key={k} style={{ textAlign: "center", flex: 1 }}><Face img={k === "team" ? "max" : k} size={40} /><div style={{ marginTop: 3 }}><Bar v={(v + 100) / 200} color={v < -15 ? "#ef4444" : v > 30 ? "#4ccb40" : "#60a5fa"} h={6} /></div></div>; })}
                </div>
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 7 }}>
                  <button className="btn blue" onClick={() => setSheet("admin")}><Icon n="brief" s={18} />Дела и интриги</button>
                  <button className="btn yellow" onClick={() => setSheet("tasks")}><Icon n="clip" s={18} />Задания{claim ? ` (${claim})` : ""}</button>
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* nav */}
      <div className="nav">
        {NAV.map((n) => (
          <button key={n.k} className={`navbtn ${loc === n.k ? "on" : ""}`} onClick={() => go(n.k)}>
            <Icon n={n.i} s={22} />{n.n}
            {n.k === "lobby" && redN > 0 && <span className="badge">{redN}</span>}
            {n.k === "ward" && s.ward.length > 0 && <span className="badge" style={{ background: "#1e6fd0", animation: "none" }}>{s.ward.length}</span>}
            {n.k === "admin" && claim > 0 && <span className="badge" style={{ background: "#f59e0b" }}>{claim}</span>}
          </button>
        ))}
      </div>

      {/* overlays */}
      {inConsult && !blocking && <Consult key={s.consult} s={s} />}
      {sheet === "map" && <MapSheet s={s} onClose={() => setSheet(null)} go={go} openProfile={() => setSheet("profile")} openMenu={() => setSheet("menu")} />}
      {sheet === "profile" && <ProfileSheet s={s} onClose={() => setSheet(null)} />}
      {sheet === "skills" && <ProfileSheet s={s} onClose={() => setSheet(null)} startTab="skills" />}
      {sheet === "menu" && <MenuSheet onClose={() => setSheet(null)} />}
      {sheet === "shop" && <ShopSheet s={s} onClose={() => setSheet(null)} />}
      {sheet === "admin" && <AdminSheet s={s} onClose={() => setSheet(null)} />}
      {sheet === "tasks" && <AdminSheet s={s} onClose={() => setSheet(null)} tab0="tasks" />}
      {(sheet === "shiftend" || forced) && !blocking && <ShiftEnd s={s} forced={forced} onClose={() => setSheet(null)} />}
      {s.summary && !s.over && s.started && <SummaryModal s={s} />}
      {!s.summary && s.pending.length > 0 && !s.over && s.started && <EventModal key={s.pending[0]} s={s} />}
      {!s.started && <Intro s={s} />}
      {s.over && <GameOver s={s} onNew={() => newCareer()} />}
      {s.toast && !s.over && <div className="toast" key={s.toast}>{s.toast}</div>}
      <span style={{ display: "none" }}>{NPC_NAME.boss}</span>
    </div>
  );
}
