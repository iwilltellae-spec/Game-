"use client";
import { useState } from "react";
import type { GameState, Loc } from "../types";
import { act, hardReset } from "../store";
import { DRUGS, QUIZ, DIS } from "../meds";
import { RANKS, SHOP, QUESTS, NPCS, OUTFIT_NAME, REL_LABEL, totalRate } from "../data";
import { ADMIN_ACTIONS, adminAction, bedCap, buyDrug, buyItem, claimQuest, examReqs, promote, wardTreat, spendTime, spendSkill, cashRate, flag, pick, note } from "../engine";
import { Sheet, Icon, Face, Bar, Sprite, fmt } from "./ui";
import { Tip, SignDoc } from "./Overlays";

/* ---------------- ward dock ---------------- */
export function WardDock({ s }: { s: GameState }) {
  const caps = bedCap(s);
  const label = (v: number) => (v < 0.35 ? ["Критическое", "#c62828"] : v < 0.6 ? ["Тяжёлое", "#d97706"] : v < 0.8 ? ["Стабильное", "#1e6fd0"] : ["Хорошее", "#2c8f2f"]);
  return (
    <div style={{ display: "grid", gap: 6, maxHeight: 250, overflowY: "auto" }} className="scroll-none">
      {!s.tips.ward && <Tip k="ward" />}
      {Array.from({ length: caps }).map((_, i) => {
        const ip = s.ward[i];
        if (!ip) return <div key={i} className="card" style={{ borderStyle: "dashed", color: "#8fa0bd", fontSize: 12, padding: 7, textAlign: "center" }}>Койка {i + 1}: свободна</div>;
        const [t, c] = label(ip.score);
        return (
          <div key={ip.id} className="card" style={{ padding: 7, display: "flex", gap: 8, alignItems: "center" }}>
            <Face img={ip.p.portrait} size={44} />
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontWeight: 800, fontSize: 13 }}>{ip.p.name}</div>
              <div style={{ fontSize: 11, color: "#51627f" }}>День {Math.min(ip.days + 1, ip.need)} из {ip.need}. <b style={{ color: c }}>{t}</b></div>
              <Bar v={ip.score} color={c} h={7} />
            </div>
            <div style={{ display: "grid", gap: 4 }}>
              <button className="btn blue sm" disabled={!!ip.treated || s.time < 1} onClick={() => act((g) => { note(g, wardTreat(g, ip.id, "drip")); })}>Капельница</button>
              <button className="btn white sm" disabled={!!ip.treated || s.time < 1} onClick={() => act((g) => { note(g, wardTreat(g, ip.id, "round")); })}>Обход</button>
            </div>
          </div>
        );
      })}
    </div>
  );
}

/* ---------------- shop ---------------- */
type ShopTab = "meds" | "equip" | "staff" | "svc" | "bed";
const TABS: [ShopTab, string][] = [["meds", "Лекарства"], ["equip", "Оборудование"], ["staff", "Штат"], ["svc", "Услуги"], ["bed", "Койки"]];
export function ShopSheet({ s, onClose }: { s: GameState; onClose: () => void }) {
  const [tab, setTab] = useState<ShopTab>("meds");
  const [msg, setMsg] = useState("");
  return (
    <Sheet title="Аптека и склад" onClose={onClose} size="h80" right={<span className="chip" style={{ background: "#fff", color: "#1d6b1b" }}><Icon n="money" s={13} />{fmt(s.money)}</span>}>
      <div style={{ display: "flex", gap: 5, overflowX: "auto", marginBottom: 8 }} className="scroll-none">
        {TABS.map(([k, n]) => <button key={k} className={`btn sm ${tab === k ? "yellow" : "white"}`} style={{ flex: "none" }} onClick={() => setTab(k)}>{n}</button>)}
      </div>
      {msg && <div className="chip bad" style={{ marginBottom: 6 }}>{msg}</div>}
      {tab === "meds" ? (
        <div style={{ display: "grid", gap: 6 }}>
          {DRUGS.map((d) => (
            <div key={d.id} className="card" style={{ padding: 7, display: "flex", alignItems: "center", gap: 8 }}>
              <span style={{ width: 30, height: 30, borderRadius: 9, background: "#e3ebf8", color: "#1e6fd0", display: "grid", placeItems: "center" }}><Icon n={d.form === "inj" ? "syringe" : d.form === "drip" ? "drop" : "pill"} s={17} /></span>
              <div style={{ flex: 1 }}>
                <div style={{ fontWeight: 800, fontSize: 13 }}>{d.name}</div>
                <div style={{ fontSize: 11, color: "#51627f" }}>На складе: <b style={{ color: (s.stock[d.id] || 0) === 0 ? "#c62828" : "#23324d" }}>{s.stock[d.id] || 0}</b> · {fmt(d.price)} за шт.</div>
              </div>
              <button className="btn sm" disabled={s.money < d.price} onClick={() => act((g) => { buyDrug(g, d.id, 1); })}>+1</button>
              <button className="btn blue sm" disabled={s.money < d.price * 5} onClick={() => act((g) => { buyDrug(g, d.id, 5); })}>+5</button>
            </div>
          ))}
        </div>
      ) : (
        <div style={{ display: "grid", gap: 7 }}>
          {SHOP.filter((i) => i.cat === tab).map((it) => {
            const own = it.cat === "staff" ? s.staff.includes(it.id) : it.cat !== "svc" && s.owned.includes(it.id);
            const locked = !!it.req && !s.owned.includes(it.req);
            return (
              <div key={it.id} className="card" style={{ padding: 9, display: "flex", alignItems: "center", gap: 8, opacity: locked ? 0.55 : 1 }}>
                <div style={{ flex: 1 }}>
                  <div style={{ fontWeight: 800, fontSize: 13.5 }}>{it.name}</div>
                  <div style={{ fontSize: 11.5, color: "#51627f", lineHeight: 1.25 }}>{it.desc}</div>
                </div>
                {own ? <span className="chip good">Куплено</span> : <button className="btn sm" disabled={locked || s.money < it.price} onClick={() => act((g) => { const r = buyItem(g, it.id); setMsg(r === "ok" ? "" : r); })}>{fmt(it.price)}</button>}
              </div>
            );
          })}
        </div>
      )}
    </Sheet>
  );
}

/* ---------------- admin ---------------- */
const STORY_HINT: Record<string, string> = {
  st1: "Пропавшие ампулы (день 2+)", st2: "Чужая заслуга (день 4+)", st3: "Акт списания (день 7+, Интерн)", st4: "Папка из корзины (день 11+)", st5: "Юбилей главврача (Ординатор, день 15+)", st6: "Слух о комиссии (день 19+)", st7: "Комиссия (через 3 дня после слуха)", st8: "Сердце главврача (Врач-терапевт, день 26+)", st9: "Вакуум власти (Ведущий врач)", st10: "Собрание коллектива (Заведующая отделением)", st11: "Выборы главного врача (Заместитель главврача)", st12: "Первый день главврача",
};
function moodOf(v: number): [string, string] { return v < -50 ? ["Враг", "#c62828"] : v < -15 ? ["Неприязнь", "#d97706"] : v < 15 ? ["Нейтрально", "#51627f"] : v < 45 ? ["Доверие", "#1e6fd0"] : ["Союзник", "#2c8f2f"]; }
type AdminTab = "plot" | "tasks" | "people" | "exam";
export function AdminSheet({ s, onClose, tab0 = "plot" }: { s: GameState; onClose: () => void; tab0?: AdminTab }) {
  const [tab, setTab] = useState<AdminTab>(tab0);
  const [signFor, setSignFor] = useState<string | null>(null);
  const [res, setRes] = useState<{ text: string; notes: string[] } | null>(null);
  const [quiz, setQuiz] = useState<{ qs: typeof QUIZ; ans: number[]; i: number } | null>(null);
  const [exam, setExam] = useState<string | null>(null);
  const [contract, setContract] = useState(false);
  const run = (id: string) => { let r = { ok: false, text: "", notes: [] as string[] }; act((g) => { r = adminAction(g, id); }); setRes({ text: r.text, notes: r.notes }); };
  const reqs = examReqs(s);
  const allOk = reqs.length > 0 && reqs.every((r) => r.ok) && s.rank < 6;
  const nextStory = Object.keys(STORY_HINT).find((k) => !flag(s, "ev_" + k));
  const startExam = () => { act((g) => { spendTime(g, 2); g.flags.exam_day = g.day; }); const qs = [...QUIZ].sort(() => Math.random() - 0.5).slice(0, 3); setQuiz({ qs, ans: [], i: 0 }); };
  const answerQ = (k: number) => {
    if (!quiz) return;
    const ans = [...quiz.ans, k];
    if (ans.length < 3) { setQuiz({ ...quiz, ans, i: quiz.i + 1 }); return; }
    const ok = ans.filter((a, i) => a === quiz.qs[i].c).length;
    setQuiz(null);
    if (ok >= 2) { setContract(true); setExam(`Ты ответила правильно на ${ok} из 3. Остаётся подписать приказ о назначении.`); }
    else { act((g) => { applyStress(g); }); setExam(`Верно только ${ok} из 3. Комиссия просит прийти позже и подучить фармакологию.`); }
  };
  return (
    <Sheet title="Дирекция" onClose={onClose} size="h80">
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 5, marginBottom: 8 }}>
        {([["plot", "Интриги"], ["tasks", "Задания"], ["people", "Люди"], ["exam", "Аттестация"]] as [AdminTab, string][]).map(([k, n]) => <button key={k} className={`btn sm ${tab === k ? "yellow" : "white"}`} style={{ padding: "6px 2px", fontSize: 12 }} onClick={() => { setTab(k); setRes(null); }}>{n}</button>)}
      </div>
      {res && <div className="card" style={{ marginBottom: 8, borderColor: "#ffc61a", background: "#fff9df" }}><div style={{ fontSize: 13, lineHeight: 1.35 }}>{res.text}</div><div style={{ display: "flex", flexWrap: "wrap", gap: 4, marginTop: 5 }}>{res.notes.map((n, k) => <span key={k} className="chip">{n}</span>)}</div><button className="btn sm block" style={{ marginTop: 6 }} onClick={() => setRes(null)}>Понятно</button></div>}
      {tab === "plot" && (
        <div style={{ display: "grid", gap: 7 }}>
          {ADMIN_ACTIONS.map((a) => {
            const done = flag(s, "adm_" + a.id) === s.day;
            return (
              <div key={a.id} className="card" style={{ display: "flex", gap: 8, alignItems: "center", padding: 9 }}>
                <div style={{ flex: 1 }}>
                  <div style={{ fontWeight: 800, fontSize: 13.5 }}>{a.name}</div>
                  <div style={{ fontSize: 11.5, color: "#51627f", lineHeight: 1.25 }}>{a.desc}</div>
                  <div style={{ fontSize: 10.5, color: "#8190aa", marginTop: 2 }}>{a.cost} ч{a.money ? `, ${a.money} ₽` : ""}. Исход неизвестен.</div>
                </div>
                <button className="btn sm" disabled={done || s.time < a.cost || (a.id === "complain" && s.dossier < 3)} onClick={() => (a.sign ? setSignFor(a.id) : run(a.id))}>{done ? "Сегодня уже" : a.sign ? "Подписать" : "Сделать"}</button>
              </div>
            );
          })}
        </div>
      )}
      {tab === "tasks" && (
        <div style={{ display: "grid", gap: 7 }}>
          {!s.tips.admin && <Tip k="admin" />}
          <div className="card" style={{ borderColor: "#ffc61a", background: "#fff9df" }}>
            <div style={{ fontSize: 11, fontWeight: 800, color: "#b8860b" }}>СЮЖЕТ</div>
            <div style={{ fontWeight: 800 }}>{nextStory ? STORY_HINT[nextStory] : "Все главы пройдены. Дальше свободная игра."}</div>
            <div style={{ fontSize: 11.5, color: "#51627f" }}>Глава начнётся в начале нового дня, когда выполнятся условия.</div>
          </div>
          <div style={{ fontWeight: 800, fontSize: 13 }}>Задания смены</div>
          {s.daily.quests.map((q) => {
            const d = QUESTS.find((x) => x.id === q.id)!;
            const v = Math.min(s.daily[d.k], d.n);
            return (
              <div key={q.id} className="card" style={{ padding: 9 }}>
                <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontWeight: 800, fontSize: 13 }}>{d.text}</div>
                    <div style={{ fontSize: 11, color: "#51627f" }}>Награда: {d.money} ₽ и {d.xp} опыта</div>
                  </div>
                  <button className="btn sm" disabled={!q.done || q.claimed} onClick={() => act((g) => claimQuest(g, q.id))}>{q.claimed ? "Получено" : q.done ? "Забрать" : `${v}/${d.n}`}</button>
                </div>
                <div style={{ marginTop: 5 }}><Bar v={v / d.n} color="#4ccb40" h={7} /></div>
              </div>
            );
          })}
        </div>
      )}
      {tab === "people" && (
        <div style={{ display: "grid", gap: 7 }}>
          {NPCS.map((n) => { const v = s.rel[n.key]; const [m, c] = moodOf(v); return (
            <div key={n.key} className="card" style={{ padding: 9, display: "flex", gap: 8 }}>
              <Face img={n.img} size={54} />
              <div style={{ flex: 1 }}>
                <div style={{ display: "flex", justifyContent: "space-between" }}><b style={{ fontSize: 13.5 }}>{n.name}</b><b style={{ fontSize: 12, color: c }}>{m}</b></div>
                <div style={{ fontSize: 11, color: "#51627f", lineHeight: 1.25, marginBottom: 4 }}>{n.role}. {n.desc}</div>
                <Bar v={(v + 100) / 200} color={c} h={8} />
              </div>
            </div>
          ); })}
          <div className="card" style={{ fontSize: 12.5, lineHeight: 1.45 }}>
            <div>Досье на Левицкого: <b>{s.dossier}</b> док.</div>
            <div>Выговоры: <b>{s.warn}</b> из 3</div>
            <div>Твой курс: <b>{s.path.flat >= s.path.whistle && s.path.flat >= s.path.rebel && s.path.flat > 0 ? "Подхалим" : s.path.whistle >= s.path.rebel && s.path.whistle > 0 ? "Разоблачитель" : s.path.rebel > 0 ? "Бунтарь" : "Пока без курса"}</b></div>
            {flag(s, "complicit") > 0 && <div style={{ color: "#c62828" }}>Твоя подпись лежит в сейфе Левицкого.</div>}
            {flag(s, "corrupt") > 0 && <div style={{ color: "#d97706" }}>За тобой водятся конверты.</div>}
          </div>
        </div>
      )}
      {tab === "exam" && (
        <div style={{ display: "grid", gap: 8 }}>
          {s.rank >= 6 ? (
            <div className="card" style={{ fontSize: 13, lineHeight: 1.4 }}>{s.rank >= 7 ? "Ты главный врач. Выше только слава." : "Должность главного врача достаётся на выборах совета. Готовь союзников: доверие Громова, досье, поддержку коллектива или договор с Левицким."}</div>
          ) : (
            <>
              <div className="card"><div style={{ fontSize: 11, color: "#51627f" }}>Следующая должность</div><div style={{ fontWeight: 800, fontSize: 17 }}>{RANKS[s.rank + 1].name}</div><div style={{ fontSize: 12 }}>Оклад: {fmt(RANKS[s.rank + 1].salary)} в смену</div></div>
              {reqs.map((r, i) => <div key={i} className="card" style={{ padding: 8, display: "flex", gap: 8, alignItems: "center", fontSize: 12.5 }}><span style={{ color: r.ok ? "#2c8f2f" : "#c62828" }}><Icon n={r.ok ? "check" : "close"} s={18} /></span>{r.label}</div>)}
              {exam && <div className="card" style={{ fontWeight: 700, fontSize: 13 }}>{exam}</div>}
              {!quiz && !contract && <button className="btn block" disabled={!allOk || s.time < 2 || flag(s, "exam_day") === s.day} onClick={startExam}>Сдать аттестацию (2 ч)</button>}
              {quiz && (
                <div className="card" style={{ borderColor: "#1e6fd0" }}>
                  <div style={{ fontSize: 11, color: "#51627f" }}>Вопрос {quiz.i + 1} из 3</div>
                  <div style={{ fontWeight: 800, margin: "4px 0 8px" }}>{quiz.qs[quiz.i].q}</div>
                  <div style={{ display: "grid", gap: 6 }}>{quiz.qs[quiz.i].a.map((a, k) => <button key={k} className="btn blue" style={{ justifyContent: "flex-start", textAlign: "left" }} onClick={() => answerQ(k)}>{a}</button>)}</div>
                </div>
              )}
              {contract && <button className="btn yellow block" onClick={() => setSignFor("contract")}><Icon n="pen" s={16} />Подписать приказ о назначении</button>}
            </>
          )}
        </div>
      )}
      {signFor && signFor !== "contract" && <SignDoc title={ADMIN_ACTIONS.find((a) => a.id === signFor)!.sign!} onCancel={() => setSignFor(null)} onSigned={() => { const id = signFor; setSignFor(null); run(id); }} />}
      {signFor === "contract" && <SignDoc title={`Приказ: назначить на должность «${RANKS[s.rank + 1]?.name}»`} onSigned={() => { setSignFor(null); setContract(false); let r: string[] = []; act((g) => { r = promote(g); }); setExam(r.join(" ")); }} />}
    </Sheet>
  );
}
function applyStress(g: GameState) { g.stress = Math.min(100, g.stress + 6); note(g, "Аттестация провалена"); }

/* ---------------- profile ---------------- */
const SKILL_INFO: Record<string, [string, string]> = {
  diag: ["Диагностика", "+1 вопрос пациенту за каждые 2 уровня. С 3 уровня скрытные пациенты не отмалчиваются."],
  pharm: ["Фармакология", "С 2 уровня видно подходящие препараты, с 4 их эффективность."],
  empathy: ["Эмпатия", "Помогает гасить скандалы и успокаивать тревожных."],
  diplo: ["Дипломатия", "Открывает мирные варианты в событиях."],
  hands: ["Золотые руки", "Шире зелёная зона при уколах."],
};
export function ProfileSheet({ s, onClose, startTab = "me" }: { s: GameState; onClose: () => void; startTab?: "me" | "skills" | "log" }) {
  const [tab, setTab] = useState<"me" | "skills" | "log">(startTab);
  const r = RANKS[s.rank], nx = RANKS[s.rank + 1];
  return (
    <Sheet title={`${s.name || "Доктор"}: ${r.name}`} onClose={onClose} size="h80">
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 5, marginBottom: 8 }}>
        {([["me", "Персонаж"], ["skills", `Навыки${s.sp ? " (" + s.sp + ")" : ""}`], ["log", "Журнал"]] as ["me" | "skills" | "log", string][]).map(([k, n]) => <button key={k} className={`btn sm ${tab === k ? "yellow" : "white"}`} onClick={() => setTab(k)}>{n}</button>)}
      </div>
      {tab === "me" && (
        <div>
          <div style={{ display: "flex", gap: 10 }}>
            <div style={{ width: 130, height: 250, borderRadius: 18, background: "linear-gradient(#f9c9d4,#bfe8f5)", border: "3px solid #fff", boxShadow: "0 0 0 3px #23324d", display: "flex", alignItems: "flex-end", justifyContent: "center", overflow: "hidden", flex: "none" }}>
              <Sprite img={`hero${r.tier}`} className="hero-idle" style={{ height: "96%", objectFit: "contain" }} />
            </div>
            <div style={{ flex: 1, display: "grid", gap: 5, alignContent: "start", fontSize: 12.5 }}>
              <div className="card" style={{ padding: 7 }}><b>{OUTFIT_NAME[r.tier]}</b><div style={{ fontSize: 11, color: "#51627f" }}>Одежда меняется с должностью.</div></div>
              <div className="card" style={{ padding: 7 }}>Опыт: <b>{s.xp}</b>{nx ? ` / ${nx.xp}` : ""}{nx && <Bar v={(s.xp - r.xp) / Math.max(1, nx.xp - r.xp)} color="#ec4899" h={7} />}</div>
              <div className="card" style={{ padding: 7 }}>Рейтинг больницы: <b>{Math.round(s.rating)}</b>/100<Bar v={s.rating / 100} color="#f59e0b" h={7} /></div>
              <div className="card" style={{ padding: 7 }}>Нервы: <b>{s.stress}</b>/100<Bar v={s.stress / 100} color={s.stress > 70 ? "#ef4444" : "#60a5fa"} h={7} /></div>
            </div>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 6, marginTop: 8, fontSize: 12.5 }}>
            <div className="card" style={{ padding: 7 }}>День: <b>{s.day}</b></div>
            <div className="card" style={{ padding: 7 }}>Вылечено: <b>{s.totals.cured}</b></div>
            <div className="card" style={{ padding: 7 }}>Потери: <b>{s.totals.deaths}</b></div>
            <div className="card" style={{ padding: 7 }}>Доход: <b>{totalRate(s)}</b>/мин</div>
          </div>
          <div style={{ marginTop: 8, display: "grid", gap: 4 }}>
            {RANKS.map((x, i) => <div key={i} style={{ fontSize: 12, display: "flex", justifyContent: "space-between", opacity: i <= s.rank ? 1 : 0.45, fontWeight: i === s.rank ? 800 : 500 }}><span>{i + 1}. {x.name}</span><span>{OUTFIT_NAME[x.tier].split(" ").slice(0, 2).join(" ")}</span></div>)}
          </div>
        </div>
      )}
      {tab === "skills" && (
        <div style={{ display: "grid", gap: 7 }}>
          <div className="chip" style={{ justifySelf: "start", background: "#fff3c4" }}>Свободных очков: {s.sp}</div>
          {(Object.keys(SKILL_INFO) as (keyof GameState["skills"])[]).map((k) => (
            <div key={k} className="card" style={{ padding: 9, display: "flex", gap: 8, alignItems: "center" }}>
              <div style={{ flex: 1 }}>
                <div style={{ fontWeight: 800, fontSize: 13.5 }}>{SKILL_INFO[k][0]}</div>
                <div style={{ fontSize: 11.5, color: "#51627f", lineHeight: 1.25 }}>{SKILL_INFO[k][1]}</div>
                <div style={{ display: "flex", gap: 3, marginTop: 4 }}>{[1, 2, 3, 4, 5].map((n) => <i key={n} style={{ width: 22, height: 8, borderRadius: 4, background: s.skills[k] >= n ? "#4ccb40" : "#dfe6f2" }} />)}</div>
              </div>
              <button className="btn sm" disabled={s.sp < 1 || s.skills[k] >= 5} onClick={() => act((g) => spendSkill(g, k))}><Icon n="plus" s={16} /></button>
            </div>
          ))}
        </div>
      )}
      {tab === "log" && (
        <div style={{ display: "grid", gap: 4 }}>
          {s.log.length === 0 && <div style={{ color: "#8190aa" }}>Записей пока нет.</div>}
          {s.log.map((l, i) => <div key={i} className="card" style={{ padding: "5px 8px", fontSize: 12 }}>{l}</div>)}
        </div>
      )}
    </Sheet>
  );
}

/* ---------------- map ---------------- */
const LOCS: { k: Loc; n: string; bg: string; d: string }[] = [
  { k: "lobby", n: "Приёмная", bg: "lobby", d: "Очередь, касса, скандалы" },
  { k: "office", n: "Кабинет", bg: "office", d: "Приём и рецепты" },
  { k: "ward", n: "Палата", bg: "ward", d: "Госпитализированные" },
  { k: "shop", n: "Аптека", bg: "office", d: "Лекарства и покупки" },
  { k: "admin", n: "Дирекция", bg: "admin", d: "Интриги и аттестация" },
];
export function MapSheet({ s, onClose, go, openProfile, openMenu }: { s: GameState; onClose: () => void; go: (l: Loc) => void; openProfile: () => void; openMenu: () => void }) {
  const status = (k: Loc) => k === "lobby" ? `Ждут: ${s.queue.length}${s.queue.some((p) => p.sev === 3) ? ", красная линия!" : ""}` : k === "ward" ? `Коек занято: ${s.ward.length}/${bedCap(s)}` : k === "office" ? (s.consult !== null ? "Идёт приём" : "Свободен") : k === "shop" ? `Склад: ${Object.values(s.stock).reduce((a, b) => a + b, 0)} шт.` : `Выговоров: ${s.warn}/3`;
  return (
    <Sheet title="Карта больницы" onClose={onClose} size="h80">
      <div style={{ display: "grid", gap: 8 }}>
        {LOCS.map((l, i) => (
          <button key={l.k} onClick={() => { go(l.k); onClose(); }} style={{ position: "relative", height: 74, borderRadius: 16, overflow: "hidden", border: s.loc === l.k ? "4px solid #ffc61a" : "4px solid #23324d", padding: 0, cursor: "pointer", textAlign: "left", animation: `pop .35s ${i * 0.06}s both`, filter: l.k === "shop" ? "hue-rotate(110deg)" : undefined }}>
            <img src={`/bg/${l.bg}.webp`} alt="" loading="lazy" style={{ position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: "cover", objectPosition: "center 60%" }} />
            <div style={{ position: "absolute", inset: 0, background: "linear-gradient(90deg, rgba(10,25,60,.85), rgba(10,25,60,.1))" }} />
            <div style={{ position: "relative", padding: "9px 12px", color: "#fff", filter: l.k === "shop" ? "hue-rotate(-110deg)" : undefined }}>
              <div style={{ fontWeight: 800, fontSize: 17 }}>{l.n}</div>
              <div style={{ fontSize: 12, opacity: 0.9 }}>{l.d}</div>
              <div style={{ fontSize: 11.5, fontWeight: 800, color: "#ffe37a" }}>{status(l.k)}</div>
            </div>
          </button>
        ))}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
          <button className="btn blue" onClick={() => { onClose(); openProfile(); }}><Icon n="person" s={18} />Персонаж</button>
          <button className="btn white" onClick={() => { onClose(); openMenu(); }}><Icon n="gear" s={18} />Меню</button>
        </div>
      </div>
    </Sheet>
  );
}

/* ---------------- settings ---------------- */
export function MenuSheet({ onClose }: { onClose: () => void }) {
  const [sure, setSure] = useState(false);
  return (
    <Sheet title="Меню" onClose={onClose} size="auto">
      <div style={{ display: "grid", gap: 10 }}>
        <div className="card" style={{ fontSize: 12.5, lineHeight: 1.4 }}>Игра сохраняется автоматически на этом устройстве. Все лекарства и ситуации выдуманы, это игра, а не медицинский совет.</div>
        {!sure ? <button className="btn red" onClick={() => setSure(true)}>Удалить прогресс и начать заново</button> : (
          <div style={{ display: "grid", gap: 6 }}>
            <div style={{ fontWeight: 800, textAlign: "center" }}>Точно удалить всё?</div>
            <button className="btn red" onClick={() => { hardReset(); onClose(); }}>Да, удалить</button>
            <button className="btn white" onClick={() => setSure(false)}>Нет, вернуться</button>
          </div>
        )}
        <button className="btn block" onClick={onClose}>Продолжить игру</button>
      </div>
    </Sheet>
  );
}
export const _x = [DIS, REL_LABEL, cashRate, pick];
