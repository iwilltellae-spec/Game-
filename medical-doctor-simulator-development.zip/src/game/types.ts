export type Loc = "lobby" | "office" | "ward" | "shop" | "admin";
export type RelKey = "boss" | "lev" | "nurse" | "rival" | "team";
export type TraitId = "calm" | "anxious" | "aggressive" | "cunning" | "rich" | "blogger" | "chatty" | "stoic";
export type Dose = "low" | "norm" | "high";
export type TestId = "exam" | "rapid" | "blood" | "xray" | "ecg" | "us";

export interface Patient {
  id: number;
  portrait: string;
  name: string;
  age: number;
  sex: "m" | "f";
  disease: string;
  allergy: string | null;
  chronic: string | null;
  trait: TraitId;
  patience: number;
  maxPatience: number;
  sev: number;
  asked: number[];
  tested: TestId[];
  conflictDone: boolean;
  vip?: boolean;
  isBoss?: boolean;
  forceId?: string;
}

export interface Inpatient {
  id: number;
  p: Patient;
  score: number;
  reward: number;
  xp: number;
  days: number;
  need: number;
  treated: number;
  hadHarm: boolean;
  drugs: string[];
}

export interface Fx {
  money?: number;
  xp?: number;
  stress?: number;
  boss?: number;
  lev?: number;
  nurse?: number;
  rival?: number;
  team?: number;
  dossier?: number;
  warn?: number;
  rating?: number;
  flat?: number;
  whistle?: number;
  rebel?: number;
  sp?: number;
  time?: number;
  set?: Record<string, number>;
  stock?: Record<string, number>;
  fire?: string;
  demote?: boolean;
  promote?: boolean;
  redPatients?: number;
  bossPatient?: boolean;
  rush?: number;
}

export interface Choice {
  t: string;
  res: string;
  fx: Fx;
  risk?: { p: number; fx: Fx; res: string };
  need?: { money?: number; dossier?: number; diplo?: number; team?: number; boss?: number; lev?: number; flag?: string; rank?: number };
  sign?: string;
}

export interface GEvent {
  id: string;
  who: string;
  title: string;
  text: string | ((s: GameState) => string);
  w: (s: GameState) => number;
  story?: boolean;
  once?: boolean;
  choices: Choice[] | ((s: GameState) => Choice[]);
}

export interface QuestState {
  id: string;
  done: boolean;
  claimed: boolean;
}

export interface GameState {
  v: number;
  name: string;
  sig: string | null;
  started: boolean;
  intro: number;
  tips: Record<string, number>;
  day: number;
  time: number;
  maxTime: number;
  money: number;
  xp: number;
  rank: number;
  sp: number;
  spGiven: number;
  skills: { diag: number; pharm: number; empathy: number; diplo: number; hands: number };
  stress: number;
  rating: number;
  warn: number;
  rel: Record<RelKey, number>;
  dossier: number;
  path: { flat: number; whistle: number; rebel: number };
  flags: Record<string, number>;
  stock: Record<string, number>;
  owned: string[];
  staff: string[];
  queue: Patient[];
  ward: Inpatient[];
  cash: number;
  cashT: number;
  nid: number;
  daily: { cured: number; earned: number; perfInj: number; red: number; tests: number; calm: number; quests: QuestState[] };
  cd: Record<string, number>;
  log: string[];
  pending: string[];
  summary: string[] | null;
  over: { kind: string; text: string } | null;
  legacy: number;
  totals: { cured: number; deaths: number; shifts: number };
  loc: Loc;
  consult: number | null;
  toast: string | null;
}
