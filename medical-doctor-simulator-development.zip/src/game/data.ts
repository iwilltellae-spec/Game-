import type { GameState, RelKey, TraitId, Fx } from "./types";

export const RANKS = [
  { name: "Практикант", xp: 0, salary: 150, tier: 0 },
  { name: "Интерн", xp: 90, salary: 260, tier: 0 },
  { name: "Ординатор", xp: 280, salary: 420, tier: 1 },
  { name: "Врач-терапевт", xp: 650, salary: 680, tier: 1 },
  { name: "Ведущий врач", xp: 1250, salary: 1050, tier: 2 },
  { name: "Заведующая отделением", xp: 2200, salary: 1650, tier: 2 },
  { name: "Заместитель главврача", xp: 3700, salary: 2600, tier: 2 },
  { name: "Главный врач", xp: 6000, salary: 4500, tier: 2 },
];

export const OUTFIT_NAME = ["Голубая форма практиканта", "Белый халат врача", "Премиальный халат руководителя"];

export interface PortraitInfo { sex: "m" | "f"; age: [number, number]; traits: TraitId[]; kid?: boolean; preg?: boolean; baby?: boolean }
export const PORTRAITS: Record<string, PortraitInfo> = {
  p0: { sex: "m", age: [6, 9], traits: ["anxious", "calm"], kid: true },
  p1: { sex: "m", age: [68, 85], traits: ["calm", "chatty", "stoic"] },
  p2: { sex: "m", age: [40, 55], traits: ["rich", "aggressive", "anxious", "cunning"] },
  p3: { sex: "f", age: [22, 35], traits: ["anxious", "calm"], preg: true },
  p4: { sex: "f", age: [14, 17], traits: ["calm", "stoic", "chatty"] },
  p5: { sex: "m", age: [30, 50], traits: ["stoic", "cunning", "calm"] },
  p6: { sex: "m", age: [35, 55], traits: ["aggressive"] },
  p7: { sex: "f", age: [68, 85], traits: ["chatty", "anxious", "calm"] },
  p8: { sex: "f", age: [20, 30], traits: ["blogger", "anxious"] },
  p9: { sex: "m", age: [18, 23], traits: ["cunning", "stoic", "calm"] },
  p10: { sex: "m", age: [0, 1], traits: ["anxious", "aggressive"], baby: true },
  p11: { sex: "f", age: [45, 60], traits: ["rich", "cunning", "aggressive"] },
};

export const NAMES = {
  mF: ["Орлов", "Белов", "Смирнов", "Крылов", "Фомин", "Громов", "Зайцев", "Лебедев", "Попов", "Ершов", "Титов", "Мартынов"],
  fF: ["Орлова", "Белова", "Смирнова", "Крылова", "Фомина", "Зайцева", "Лебедева", "Попова", "Ершова", "Титова", "Мартынова", "Соколова"],
  mN: ["Пётр", "Иван", "Олег", "Денис", "Сергей", "Артём", "Игорь", "Антон", "Степан", "Борис", "Глеб"],
  fN: ["Мария", "Анна", "Ольга", "Вера", "Наталья", "Ирина", "Полина", "Алиса", "Юлия", "Тамара", "Светлана"],
};

export const TRAIT_INFO: Record<TraitId, { name: string; hint: string }> = {
  calm: { name: "Спокойный", hint: "Не создаёт проблем." },
  anxious: { name: "Тревожный", hint: "Быстро теряет терпение, нужна поддержка." },
  aggressive: { name: "Скандалист", hint: "Любит поорать на врача." },
  cunning: { name: "Хитрый", hint: "Может выпрашивать больничный или совать конверт." },
  rich: { name: "Состоятельный", hint: "Платит вдвое, но требует особого отношения." },
  blogger: { name: "Блогер", hint: "Любой промах окажется в сети." },
  chatty: { name: "Болтливый", hint: "Отнимает время разговорами." },
  stoic: { name: "Скрытный", hint: "Отвечает неохотно, часть ответов расплывчата." },
};

export interface Npc { key: RelKey; name: string; role: string; img: string; desc: string }
export const NPCS: Npc[] = [
  { key: "boss", name: "Аркадий Громов", role: "Главный врач", img: "boss", desc: "Строгий старик, любит порядок, но падок на уважение." },
  { key: "lev", name: "Виктор Левицкий", role: "Заместитель главврача", img: "lev", desc: "Улыбчивый и опасный. Кажется, лекарства пропадают не просто так." },
  { key: "nurse", name: "Зинаида Павловна", role: "Старшая медсестра", img: "nurse", desc: "Знает всё и обо всех. Её сплетни стоят дорого." },
  { key: "rival", name: "Диана Ветрова", role: "Врач, конкурентка", img: "rival", desc: "Амбициозна, остра на язык. Враг или союзник, зависит от тебя." },
  { key: "team", name: "Коллектив", role: "Макс и остальные", img: "max", desc: "Простые врачи и санитары. Их поддержка решает исход выборов." },
];

export const NPC_NAME: Record<string, string> = { boss: "Громов", lev: "Левицкий", nurse: "Зинаида Павловна", rival: "Диана", max: "Макс", inspector: "Проверяющая", sys: "Больница", team: "Коллектив" };

export interface ShopItem { id: string; cat: "equip" | "staff" | "decor" | "svc" | "bed"; name: string; desc: string; price: number; fx?: Fx; req?: string }
export const SHOP: ShopItem[] = [
  { id: "ecg", cat: "equip", name: "Аппарат ЭКГ", desc: "Открывает ЭКГ при приёме.", price: 1800 },
  { id: "us", cat: "equip", name: "Аппарат УЗИ", desc: "Открывает УЗИ при приёме.", price: 4500 },
  { id: "xray", cat: "equip", name: "Рентген-кабинет", desc: "Открывает рентген при приёме.", price: 7000 },
  { id: "analyzer", cat: "equip", name: "Автоанализатор", desc: "Анализы и экспресс-тесты не тратят время.", price: 2800 },
  { id: "coffee", cat: "equip", name: "Кофемашина", desc: "+1 час к каждой смене.", price: 1400 },
  { id: "cam", cat: "equip", name: "Камера на складе", desc: "Воровство лекарств прекращается, а запись пойдёт в досье.", price: 2500, fx: { dossier: 1 } },
  { id: "b3", cat: "bed", name: "Третья койка", desc: "Вместимость палаты 3.", price: 2500 },
  { id: "b4", cat: "bed", name: "Четвёртая койка", desc: "Вместимость палаты 4.", price: 5000, req: "b3" },
  { id: "b5", cat: "bed", name: "Пятая койка", desc: "Вместимость палаты 5.", price: 9000, req: "b4" },
  { id: "b6", cat: "bed", name: "Шестая койка", desc: "Вместимость палаты 6.", price: 15000, req: "b5" },
  { id: "q6", cat: "bed", name: "Расширить приёмную", desc: "Очередь вмещает на 2 человека больше.", price: 3500 },
  { id: "nurse_h", cat: "staff", name: "Младшая медсестра", desc: "Пассивный доход +3 в минуту, помогает в палате.", price: 1500 },
  { id: "lab", cat: "staff", name: "Лаборант", desc: "Пассивный доход +2 в минуту, ошибок в анализах нет.", price: 2200 },
  { id: "admin", cat: "staff", name: "Администратор", desc: "Пациенты ждут дольше на 2 часа.", price: 3000 },
  { id: "guard", cat: "staff", name: "Охранник", desc: "Скандалы в приёмной гасятся чаще.", price: 2500 },
  { id: "cleaner", cat: "staff", name: "Санитарка", desc: "Стресс падает на 4 за смену.", price: 1200 },
  { id: "resid", cat: "staff", name: "Помощник-ординатор", desc: "Каждую смену принимает лёгких пациентов (+доход).", price: 6000 },
  { id: "plants", cat: "decor", name: "Цветы в кабинете", desc: "Стресс падает на 3 за смену.", price: 1000 },
  { id: "tv", cat: "decor", name: "Телевизор в приёмной", desc: "Пациенты терпеливее на 2 часа.", price: 2000 },
  { id: "sofa", cat: "decor", name: "Мягкие диваны", desc: "Пациенты терпеливее на 1 час.", price: 1800 },
  { id: "poster", cat: "decor", name: "Дипломы на стене", desc: "Рейтинг больницы +4 сразу.", price: 1500, fx: { rating: 4 } },
  { id: "sweets", cat: "svc", name: "Конфеты медсёстрам", desc: "Зинаида Павловна будет добрее.", price: 400, fx: { nurse: 6 } },
  { id: "flowers", cat: "svc", name: "Букет для главврача", desc: "Громов растроган, но запомнит подхалимство.", price: 700, fx: { boss: 6, flat: 1 } },
  { id: "cognac", cat: "svc", name: "Коньяк для Левицкого", desc: "Виктор любит подарки.", price: 1500, fx: { lev: 8, flat: 1 } },
  { id: "pizza", cat: "svc", name: "Пицца для коллектива", desc: "Коллеги вспомнят добрым словом.", price: 600, fx: { team: 4 } },
  { id: "massage", cat: "svc", name: "Массаж спины", desc: "Стресс -35.", price: 900, fx: { stress: -35 } },
  { id: "course", cat: "svc", name: "Платный курс повышения", desc: "+1 очко навыков.", price: 2500, fx: { sp: 1 } },
  { id: "ads", cat: "svc", name: "Реклама больницы", desc: "Рейтинг +3.", price: 1200, fx: { rating: 3 } },
];

export interface QuestDef { id: string; text: string; k: "cured" | "earned" | "perfInj" | "red" | "tests" | "calm"; n: number; money: number; xp: number; rank?: number }
export const QUESTS: QuestDef[] = [
  { id: "q_cure2", text: "Вылечить 2 пациентов", k: "cured", n: 2, money: 150, xp: 8 },
  { id: "q_cure4", text: "Вылечить 4 пациентов", k: "cured", n: 4, money: 350, xp: 18 },
  { id: "q_earn", text: "Заработать 600 за смену", k: "earned", n: 600, money: 200, xp: 10 },
  { id: "q_earn2", text: "Заработать 1500 за смену", k: "earned", n: 1500, money: 500, xp: 20, rank: 2 },
  { id: "q_inj", text: "Сделать идеальный укол", k: "perfInj", n: 1, money: 200, xp: 12 },
  { id: "q_tests", text: "Провести 3 обследования", k: "tests", n: 3, money: 150, xp: 10 },
  { id: "q_red", text: "Спасти пациента из красной зоны", k: "red", n: 1, money: 400, xp: 25, rank: 1 },
  { id: "q_calm", text: "Успокоить скандалиста", k: "calm", n: 1, money: 250, xp: 14 },
];

export const REL_LABEL: Record<RelKey, string> = { boss: "Громов", lev: "Левицкий", nurse: "Зинаида", rival: "Диана", team: "Коллектив" };

export const TIPS: Record<string, { who: string; text: string }> = {
  queue: { who: "boss", text: "Это приёмная. Цветная рамка показывает срочность: зелёная спокойно, жёлтая быстрее, красная это красная линия. Красных нужно брать первыми!" },
  talk: { who: "max", text: "Сначала расспроси пациента. У тебя ограниченное число вопросов, выбирай умно. Обследования тратят час смены." },
  allergy: { who: "nurse", text: "Всегда спрашивай про аллергию и хронические болезни. Один неверный препарат может убить." },
  diag: { who: "boss", text: "Теперь поставь диагноз. Похожие болезни рядом нарочно. Ошибёшься, лечение будет хуже." },
  rx: { who: "nurse", text: "Выбери до двух препаратов и дозу. Проверяй возраст, аллергию и хронику. Потом подпись и печать на рецепт." },
  inj: { who: "max", text: "Уколы делают с умом: останови стрелку в зелёной зоне. Или поручи медсестре, но результат не гарантирован." },
  ward: { who: "nurse", text: "Госпитализированные лежат здесь. Каждую смену навещай их: капельница или обход повышают шанс на выздоровление." },
  admin: { who: "boss", text: "Это дирекция. Здесь аттестация, интриги и отношения. Льсти, жалуйся, плети союзы или иди своим путём." },
  shop: { who: "nurse", text: "Склад и магазин. Лекарства заканчиваются, а часть из них исчезает сама собой..." },
};

export const INTRO = [
  { who: "boss", text: "Добро пожаловать в Городскую больницу имени Святой Анны. Я Аркадий Громов, главврач. Ты у нас новенькая. Практикантов здесь любят и немножко едят." },
  { who: "nurse", text: "Я Зинаида Павловна. Склад, палата и все слухи через меня. Запомни: лекарства здесь пропадают чаще, чем должны. Не спрашивай, кто. Просто смотри." },
  { who: "lev", text: "Виктор Левицкий, заместитель главного. Если нужна помощь, обращайся ко мне. Всегда рад поддержать способных людей. Очень рад." },
  { who: "rival", text: "Диана. Тоже на повышение метишь? Забавно. Посмотрим, кто из нас сядет в кресло главврача." },
];

export function totalRate(s: GameState): number {
  let r = s.rating * 0.06 + s.rank * 1.5;
  if (s.staff.includes("nurse_h")) r += 3;
  if (s.staff.includes("lab")) r += 2;
  if (s.staff.includes("resid")) r += 6;
  return Math.round(r * 10) / 10;
}
