"use client";
import { useSyncExternalStore } from "react";
import type { GameState } from "./types";
import { freshState, clone, SAVE_KEY, tickCash } from "./engine";

let state: GameState | null = null;
const subs = new Set<() => void>();
let timer: ReturnType<typeof setTimeout> | null = null;

function emit() { subs.forEach((f) => f()); }
function save() {
  if (timer) clearTimeout(timer);
  timer = setTimeout(() => {
    try { if (state) localStorage.setItem(SAVE_KEY, JSON.stringify({ ...state, toast: null })); } catch { /* storage unavailable */ }
  }, 350);
}
export function loadGame() {
  if (state) return;
  try {
    const raw = localStorage.getItem(SAVE_KEY);
    if (raw) { const p = JSON.parse(raw) as GameState; if (p && p.v === 1) state = p; }
  } catch { /* ignore */ }
  if (!state) state = freshState();
  tickCash(state, Date.now());
  emit();
}
export function useGame(): GameState | null {
  return useSyncExternalStore((cb) => { subs.add(cb); return () => { subs.delete(cb); }; }, () => state, () => null);
}
export function act(fn: (s: GameState) => void) {
  if (!state) return;
  const n = clone(state);
  fn(n);
  state = n;
  emit();
  save();
}
export function newCareer() {
  const old = state;
  const legacy = (old?.legacy ?? 0) + 1;
  state = freshState(legacy, old?.name ?? "", old?.sig ?? null);
  state.started = true; state.intro = 99;
  beginShift(state);
  emit(); save();
}
export function hardReset() {
  state = freshState();
  emit(); save();
}
export function beginShift(s: GameState) {
  s.started = true;
}
